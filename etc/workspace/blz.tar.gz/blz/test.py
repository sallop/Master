from math import *

def f(x): return x*x

x  = [0, 1, 2, 3, 4, 5, 6, 7]
pr = [0.125 for i in range(0,8)]
mu = 3.5

sum = 0.0
for i in range(0,len(x)):
    sum += f(i-mu)*pr[i]
    print sum


print "(%d)"
