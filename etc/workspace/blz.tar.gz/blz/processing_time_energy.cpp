#include <iostream>
#include <cstring>
#include <ctime>
#include <sys/time.h>
#include "BoltzmannMachine.hpp"


void dtob(int src, Pattern& dst)
{
  for (size_t i=0; i < dst.size(); i++)
    dst[i] = (src >> i) & 0x01;
}

template<size_t T>
void dtob(int src, double dst[T])
{
  for (size_t i=0; i < T; i++)
    dst[i] = static_cast<double>((src >> i) & 0x01);
}

double gettimeofday_sec()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

template<size_t T>
double energy(double W[T][T], double x[T])
{
  double energy = 0.0;
  for (size_t i=0; i < T; i++){
    for (size_t j=0; j < i; j++){
      energy += W[i][j]*x[j];
    }
  }
  return energy;
}


int main(int argc, char** argv)
{
  int degree = atoi(argv[1]);
  int number_of_allpattern = 0x01 << degree;
  //const size_t time = 1000000;	// 10^6 pattern
  const size_t time = 10000;	// 10^4 pattern
  TimeOfRepeat T(time);
  KstepGibbsSampling K(1000);
  DegreeOfVisibleVector D(degree);
  std::vector<Pattern> all_pattern(number_of_allpattern, Pattern(degree));
  double t1,t2;
  
  //double prob[degree] = {0.25, 0.25, 0.25, 0.25};
  Probability input_pattern_distribution(number_of_allpattern, 1.0/number_of_allpattern);
  //   double aryW[degree][degree];
  //   double aryx[degree];
  //   double all_array[0x01 << degree][degree];
  // for (size_t i=0; i < all_pattern.size(); i++){
  //     dtob(i, all_pattern[i]);
  //     //std::cout << "all_pattern[" << i << "]=" << all_pattern[i] << std::endl;
  //   }
  //   for (size_t i=0; i < (0x01<<degree); i++){
  //     dtob<degree>(i, all_array[i]);
  //     //std::cout << "all_pattern[" << i << "]=" << all_pattern[i] << std::endl;
  //   }

  BoltzmannMachine1L *pblz = new BoltzmannMachine1L(&all_pattern, T, K, D,
						    input_pattern_distribution);
  
  //FILE *fp = fopen("~/Desktop/TODO/progress_report/dir-dat/pt-energy.dat","w");
  Layer W(degree, degree);
  t1 = gettimeofday_sec();
  for (size_t j=0; j < time; j++){
    for (size_t i=0; i < all_pattern.size(); i++){
      const Pattern& x = all_pattern[i];
        //pblz->energy(W,x);
      pblz->energy2(W,x);
    }
  }
  // for (size_t i = 0; i < time; i++){
  //     for (size_t j = 0; j < (0x01<<degree); j++){
  //       energy<degree>(aryW, all_array[j]);
  //     }
  //   }
  t2 = gettimeofday_sec();

  std::cout << degree << "\t" << t2 - t1 << std::endl;
  //fclose(fp);



  return 0;
}
