#!/usr/bin/ruby

def mkcmd(cmd, d, w, k)
  "./#{cmd} #{d} #{w} #{k}"
end

def mkofn(cmd, d, w, k)
  dstr = "%02d"%[d]
  wstr = ("%.2f"%[w]).gsub('.','')
  kstr = "%04d"%[k]
  "./#{cmd}_d#{dstr}_w#{wstr}_k#{kstr}.dat"
end

def get_id(name)
  s, e = 0, 0
  s = name.rindex('-') + 1
  e = name.rindex('.dat')
  if e then
    e = e - 1
  else
    e = name.size - 1
  end
  return name[s..e]
end

dirnames = [
            "dir-dat-d3h0",
            "dir-dat-d3hm",
            "dir-dat-d3hp"
           ]

files = [
         "kadai1h-p.dat"  ,
         "kadai23h-p.dat" ,
         "kadai23h-W.dat" ,
         "kadai4h-fij.dat",
         "kadai4h-KL.dat" ,
         "kadai4h-W.dat"  ,
         "kadai4h-p.dat"  ,
         "kadai5h-fij.dat",
         "kadai5h-px1.dat",
         "kadai5h-W.dat"  
        ]

parg_1h_p   = [
               "set output '%s.eps'\n",
               "set title 'numer of x'\n",
               "plot '%s' u 1:2:(0.3) with boxes fs solid 0.7 title 'numer of x'\n",
               "set title 'probability'",
               "set output '%s.eps'\n",
               "plot '%s' u ($1+0.3):3:(0.3) with boxes fs solid 0.7 title 'p(x)'\n"
              ]

parg_23h_p  = [
               "set title '23h-p(x)'\n",
               "set output '%s.eps'\n",
               "plot '%s' u 1:2:(0.3) with boxes fs solid 0.7 title '23h-p(x)','' u ($1+0.3):3:(0.3) with boxes fs solid 0.7 title 'l1=10^3', '' u ($1+0.6):3:(0.3) with boxes fs solid 0.7 title 'l2=10^6'\n"
              ]

parg_23h_W  = [
               "set title '23h-W'\n",
               "set output '%s.eps'\n",
               "set cbrange[-3:3]\n",
               "plot '%s' matrix with image title '23h-W'\n"
              ]

parg_4h_KL  = [
               "set title '4h-KL'\n",
               "set output '%s.eps'\n",
               "plot '%s' w l title '4h-KL'\n"
              ]

parg_4h_fij = [
               "set title '4h-fij'\n",
               "set output '%s.eps'\n",
               "set cbrange[-3:3]\n"  ,
               "plot '%s' matrix with image title '4h-fij'\n"
              ]

parg_4h_W   = [
               "set title '4h-W'\n",
               "set output '%s.eps'\n",
               "set cbrange[-3:3]\n"  ,
               "plot '%s' matrix with image title '4h-W'\n"
              ]

parg_4h_p   = [
               "set title '4h-p'\n",
               "set output '%s.eps'\n",
               "plot '%s' u 1:2:(0.3) with boxes fs solid 0.7 title '4h-q(x)','' u ($1+0.3):3:(0.3) with boxes fs solid 0.7 title '4h-p(x)'\n"
              ]

parg_5h_fij = [
               "set title '5h-fij'\n",
               "set output '%s.eps'\n",
               "set cbrange[-3:3]\n"  ,
               "plot '%s' matrix with image title '5h-fij'\n"
              ]

parg_5h_px1 = [
               "set title '5h-px1'\n",
               "set output '%s.eps'\n",
               "plot '%s' u 1:2:(0.3) with boxes fs solid 0.7 title 'q(x)','' u ($1+0.3):3:(0.3) with boxes fs solid 0.7 title 'p(x)'\n"
              ]

parg_5h_W   = [
               "set title '5h-W'\n",
               "set output '%s.eps\n'",
               "set cbrange[-3:3]\n"  ,
               "plot '%s' matrix with image title '5h-W'\n"
              ]

# Not implimented
#parg_5h_qn   = [
#                "set title '5h-qn'\n",
#                "set output '%s.eps\n'",
#                "plot '%s' matrix with image title '5h-W'\n"
#              ]


fctbl = {
  "kadai1h-p.dat"  => parg_1h_p  ,
  "kadai23h-p.dat" => parg_23h_p ,
  "kadai23h-W.dat" => parg_23h_W ,
  "kadai4h-KL.dat" => parg_4h_KL ,
  "kadai4h-fij.dat"=> parg_4h_fij,
  "kadai4h-W.dat"  => parg_4h_W  ,
  "kadai4h-p.dat"  => parg_4h_p  ,
  "kadai5h-fij.dat"=> parg_5h_fij,
  "kadai5h-px1.dat"=> parg_5h_px1,
  "kadai5h-W.dat"  => parg_5h_W  ,
}

IO.popen("gnuplot -persist","w") do |gp|
  gp.puts "set grid"
  gp.puts "set terminal postscript enhanced color eps"
  dirnames.each do |dir|
    files.each do |file|
      puts "#{dir}/#{file}"
      cmds = fctbl[file]
      cmds.each do |cmd|
        if /plot/ =~ cmd
          sendcmd = sprintf(cmd, "#{dir}/#{file}")
          gp.puts(sendcmd)
        elsif /output/ =~ cmd
          e = file.rindex('.') - 1
          sendcmd = sprintf(cmd, "#{dir}/#{file[0..e]}")
          gp.puts(sendcmd)
        else
          gp.puts(cmd)
        end
      end
      gp.puts "pause 3.0"
      puts "\n"
    end
  end

  #  gp.puts "set key top left"
  #  gp.puts "e"
  
end

#IO.popen("gnuplot -persist","w") do |gp|
#  gp.puts "set grid"
##  gp.puts "set terminal postscript enhanced color eps"
##  gp.puts "set key top left"
#
#  files.each_pair{|key, val_files|
#    dataset = [] #files[key_w].each{|fname|
#    val_files.each{|fname|
#      File::open( fname ){|file|
#        while line = file.gets
#          if not line =~ /^#/ then
#            data = line.chomp.strip.split
#            data = data.collect{|s| s.to_f}
#            dataset.push( data )
#          end
#        end
#      }
#    }
#    
#    d = 0
#    w = 0
#    k = 0
#    plotarg = val_files.collect{|fname|
#      fname =~ /d(\d+)_w(\d+)_k(\d+)/
#      d = $1
#      w = $2
#      k = $3
#      "'-' with lines title 'w=#{w}'"
#    }.join(",")
#    gp.puts "set output '#{command}_d#{d}_w#{w}_k#{k}.eps'"
#    gp.puts "plot #{plotarg}"
#    dataset.each{|state|
#      state.each{|prob| 
#        gp.puts prob 
#      }
#      gp.puts "e"
#    }
#    gp.puts "pause 3.0"
#  }
#end
# sendcmds     = []
# output_files = []
# cmdofiletbl  = []
# for i in 0..value_of_W.size-1
#   for j in 0..k_steps.size-1
#     cmd = mkcmd(command, init_onbit, value_of_W[i], k_steps[j])
#     ofn = mkofn(command, init_onbit, value_of_W[i], k_steps[j])
#     sendcmds.push(cmd)
#     output_files.push(ofn)
#     cmdofiletbl.push( [cmd, ofn] )
#   end
# end
# 
# cmdofiletbl.each do |cmd, ofile|
#   lines   = []
#   dataset = []
#   IO.popen( cmd ){|io|
#     while io.gets()
#       lines.push($_)
#       # ruby's false is only { nil, false }
#       data = $_.chomp.strip.split if not $_ =~ /^#/ 
#     end
#   }
#   File.open(ofile, 'w'){|dest| dest.write( lines ) }
# end
