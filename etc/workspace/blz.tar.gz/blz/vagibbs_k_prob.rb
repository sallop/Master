#!/usr/bin/ruby

command = "va_gibbs3"

init_onbit = 0
value_of_W = (0..4).collect{|i| i*0.1}
k_steps = [100]
#k_steps = [1, 10, 20, 30, 40]
#k_steps = (1..8).collect{|n| n}

def mkcmd(cmd, d, w, k)
  "./#{cmd} #{d} #{w} #{k}"
end

def mkofn(cmd, d, w, k)
  dstr = "%02d"%[d]
  wstr = ("%.2f"%[w]).gsub('.','')
  kstr = "%04d"%[k]
  "./#{cmd}_d#{dstr}_w#{wstr}_k#{kstr}.dat"
end

sendcmds     = []
output_files = []
cmdofiletbl  = []
for i in 0..value_of_W.size-1
  for j in 0..k_steps.size-1
    cmd = mkcmd(command, init_onbit, value_of_W[i], k_steps[j])
    ofn = mkofn(command, init_onbit, value_of_W[i], k_steps[j])
    sendcmds.push(cmd)
    output_files.push(ofn)
    cmdofiletbl.push( [cmd, ofn] )
  end
end

cmdofiletbl.each do |cmd, ofile|
  lines   = []
  dataset = []
  IO.popen( cmd ){|io|
    while io.gets()
      lines.push($_)
      # ruby's false is only { nil, false }
      data = $_.chomp.strip.split if not $_ =~ /^#/ 
    end
  }
  File.open(ofile, 'w'){|dest| dest.write( lines ) }
end

files = {}
output_files.each{|ofname|
  #w = $1 if ofname =~ /w(\d+)/
  w = $1 if ofname =~ /k(\d+)/
  if files[w] == nil
    files[w] = [ofname]
  else
    files[w].push( ofname )
  end
}

files.each{|key, val|
  val.sort!{|a,b| 
    a_key = $1 if a =~ /k(\d+)/
    b_key = $1 if b =~ /k(\d+)/
    a_key <=> b_key
  }
}

IO.popen("gnuplot -persist","w") do |gp|
  gp.puts "set grid"
  gp.puts "set terminal postscript enhanced color eps"
  gp.puts "set key top left"

  files.each_pair{|key, val_files|
    dataset = [] #files[key_w].each{|fname|
    val_files.each{|fname|
      File::open( fname ){|file|
        while line = file.gets
          if not line =~ /^#/ then
            data = line.chomp.strip.split
            data = data.collect{|s| s.to_f}
            dataset.push( data )
          end
        end
      }
    }
    
    d = 0
    w = 0
    k = 0
    plotarg = val_files.collect{|fname|
      fname =~ /d(\d+)_w(\d+)_k(\d+)/
      d = $1
      w = $2
      k = $3
      "'-' with lines title 'w=#{w}'"
    }.join(",")
    gp.puts "set output '#{command}_d#{d}_w#{w}_k#{k}.eps'"
    gp.puts "plot #{plotarg}"
    dataset.each{|state|
      state.each{|prob| 
        gp.puts prob 
      }
      gp.puts "e"
    }
    gp.puts "pause 3.0"
  }
end
