#include <cstdio>
#include <cmath>
#include <iostream>
#include <iterator>
#include <vector>
#include <algorithm>
#include <numeric>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>

typedef boost::numeric::ublas::vector<int> Pattern;
typedef boost::numeric::ublas::matrix<double> Layer;

using namespace std;

template<typename Iter>
Iter dtob(int d, Iter p0, Iter pN)
{
  int n = pN - p0 + 1;
  while (n--){ *pN-- = d & 0x01; d >>= 1;}
  return p0;
}

template<typename Iter>
double btod(Iter p0, Iter pN)
{
  double sum = 0.0;
  int order = 0x01 << (pN - p0);
  while (order){ sum += (*p0++)*order; order >>= 1;}
  return sum;
}

double energy(const Layer& W, const Pattern& x)
{
  double sum=0.0;
  for (size_t j=0; j < W.size2(); ++j){
    for (size_t i=0; i < W.size1(); ++i){
      sum += W(i,j)*x[i]*x[j];
    }
  }
  return exp(-sum);
}

double partial_sum(const Layer &W, const vector<Pattern> &all_pattern)
{
  double sum=0.0;
  for (size_t i=0; i < all_pattern.size(); ++i){
    sum += energy(W, all_pattern[i]);
  }
  return sum;
}

double sequential_sum(const Pattern &x)
{
  double mean = 0.0;
  for (size_t i=0; i < x.size(); ++i){
    mean = mean + (1.0/(i+1.0))*(x[i] - mean);
  }
  return mean;
}

int main(int argc, char* argv[])
{
  const size_t D = 6;
  const size_t number_of_allpattern = 0x01 << D;
  double Q[D] = {0.1, 0.2, 0.3, 0.4, 0.0, 0.3};
  double ene = 0.0;
  double sum = 0.0;
  Layer W(D,D);
  Pattern x(D,0), y(D,0);

  vector<Pattern> all_pattern(number_of_allpattern, Pattern(D,0));
  for (size_t i=0; i < number_of_allpattern; ++i){
    Pattern& x = all_pattern[i];
    x[0] = 1;
    dtob(i, x.begin()+1, x.end()-1);
    printf("i=%d\t", i);
    copy(x.begin(), x.end(), ostream_iterator<int>(cout, "\t"));
  }
  
  for (size_t i=0; i < D; ++i){
    for (size_t j=0; j < D; ++j){
      W(i,j) = 0.5;
    }
    W(i,i) = 0.0;
  }

  sum = 0.0;
  for (size_t i=0; i < number_of_allpattern; ++i){
    double ene = 0.0;
    printf("i=%2d\t", i);
    ene = energy(W, all_pattern[i]);
    printf("energy = %.4lf\n", ene);
    sum += ene;
  }
  printf("sum = %lf\n", sum);

  sum = partial_sum(W, all_pattern);
  printf("sum = %lf\n", sum);

  ene
    = energy(W, all_pattern[3])
    / partial_sum(W, all_pattern);
  printf("ene = %lf\n", ene);
  
  double *enes = new double[number_of_allpattern];
  for (size_t i=0; i < number_of_allpattern; ++i){
    enes[i] = energy(W, all_pattern[i]);
  }
  
  double mean = enes[3];
  for (size_t i=0; i < number_of_allpattern; ++i){
    mean = mean + (1.0/(i+1.0))*(enes[i] - mean);
  }
  printf("mean = %lf\n", mean);
  
  mean 
    = accumulate(enes, enes + number_of_allpattern, 0.0)
    / number_of_allpattern;
  printf("mean = %lf\n", mean);

  return 0;
}
