#include <iostream>
#include <cmath>
#include <string>
#include <iterator>
#include <functional>
#include <algorithm>
#include <boost/bind.hpp>

using namespace std;

bool is_ordered(int a, int b, int c)
{ return a <= b && b <= c; }

double sigmoid(double x)
{
  return 1./(1.+exp(-x));
}

int main()
{
  int ary[] = {1,2,3,4,5,6,7,8,9,10};
  const int len = sizeof(ary)/sizeof(ary[0]);
  int *f = find_if( ary, ary + len, boost::bind(is_ordered, 7, _1, 12));
  cout << *f << endl;

  string strary[] = {"Hello","my_name","is_k","inaba","bye!"};
  transform(strary, strary + 5, ostream_iterator<string>(cout,","),
	    boost::bind(&string::substr, _1, 1, 3));
  cout << endl;
  int foo[] = {7,3,4,9,1,2,5,8};
  sort( foo, foo + sizeof(foo)/sizeof(foo[0]),
	boost::bind(less<int>(), _2, _1) );
  copy( foo, foo + len, ostream_iterator<int>(cout,","));
  cout << endl;

  double x[5]={0.1, 0.2, 0.3, 0.4, 0.5};
  double y[5];
  transform( x, x + 5, y, boost::bind(sigmoid, _1));
  copy( y, y + 5, ostream_iterator<double>(cout,"y=\n"));
  return 0;
}
