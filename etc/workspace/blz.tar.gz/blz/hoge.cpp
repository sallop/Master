#include <cstdio>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <new>
#include <numeric>
#include <algorithm>
#include <stdexcept>
  
using namespace std;

class BoltzmannMachine
{
public:
  BoltzmannMachine(){};
  virtual double energy(){
    cout << __FUNCTION__ << "-" << __LINE__ << std::endl;
    cout << "BoltzmannMachine" << "-" << __LINE__ << std::endl;
    return 100;
  }
  
};

class BoltzmannMachine1L : public BoltzmannMachine
{
public:
  BoltzmannMachine1L(){};
  double energy(){ return BoltzmannMachine::energy() + 10; }
};

class BoltzmannMachine1L_threshold : public BoltzmannMachine1L
{
public:
  BoltzmannMachine1L_threshold(){};
  virtual double energy(){
    cout << __FUNCTION__ << "-" << __LINE__ << std::endl;
    cout << "BoltzmannMachine1L_threshold" << "-" << __LINE__ << std::endl;
    return BoltzmannMachine1L::energy() + 1;
  }
};

int main(int argc, char** argv)
{
  BoltzmannMachine *pblz = new BoltzmannMachine1L_threshold();
  cout << pblz->energy() << endl;
  vector<double> x(8, 1), y(8, 1);

  cout << inner_product(x.begin(), x.end(), y.begin(), 0.0) << endl;
  return 0;
}
