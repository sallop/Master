#include <cstdio>
#include <cassert>
#include <algorithm>
#include <iostream>
#include <iterator>
#include <fstream>
#include <functional>
#include <boost/mem_fn.hpp>
#include <boost/bind.hpp>
#include "BoltzmannMachine.hpp"

void pVector(const Pattern& v)
{
  for (size_t i=0; i < v.size(); ++i){
    printf("%.3lf\t", v[i]);
  }
  printf("\n");
}

void pLayer(const Layer& layer)
{
  for (size_t i=0; i < layer.size1(); ++i){
    for (size_t j=0; j < layer.size2(); ++j){
      printf("%.3lf\t", layer(i,j));
    }
    printf("\n");
  }
}

class Kadai1_simulation : public BoltzmannMachine1L
{
public:
  Kadai1_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    Probability &input_pattern_distribution)
    : BoltzmannMachine1L(pall_pattern, T, K, D, input_pattern_distribution)
  {
    double pr_cell[]={0.0, 0.333, 0.333, 0.333};
    set_select_cell(std::vector<Probability>
		    (1, Probability(pr_cell, pr_cell+D_)));
  }

  void start()
  {
    FILE* fp = fopen("dir-dat/kadai1.dat", "w");
    std::vector<int> histogram( N_, 0 );
    Pattern x(D_, 0);
    for (size_t t = 0; t < T_; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin()+1, x.end()-1);
      histogram[n]++;
    }

    for(size_t n=0; n < N_; n++){
      fprintf(fp, "%d %d %lf\n", n, histogram[n],
	      static_cast<double>(histogram[n])/
	      static_cast<double>(T_));
    }
    fclose(fp);
  }
};

class Kadai23_simulation : public BoltzmannMachine1L
{
public:
  Kadai23_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution)
    : BoltzmannMachine1L(pall_pattern, T, K, D, input_pattern_distribution)
  {
    double pr_cell[]={0.0, 0.333, 0.333, 0.333};
    set_select_cell(std::vector<Probability>
		    (1, Probability(pr_cell, pr_cell+D_)));
  }

  // double energy(const Layer& W, const Pattern& x)
//   { //-*-original-*-
//     double sum = 0.0;
//     for (size_t j=0; j < W.size2(); ++j){
//       sum += W(0,j)*x(j);
//     }
//     for (size_t j=1; j < W.size2(); ++j){
//       for (size_t i=1; i < j; i++){
// 	sum += W(i,j)*x(i)*x(j);
//       }
//     }
//     return -sum;
//   }
  
  Layer embed_pattern(const Pattern& x)
  {
    Layer W(x.size(), x.size());
    for (size_t i=0; i < W.size1(); ++i){
      for (size_t j=0; j < W.size2(); ++j){
	W(i,j) = (2.0*x[i] - 1.0)*(2.0*x[j] - 1.0);
      }
    }
    std::cout << "W=" << W << std::endl;
    return W;
  }
  
  void start()
  {
    FILE* fp = fopen("dir-dat/kadai2.dat", "w");
    const size_t l1 = 1000, l2 = 1000000;
    std::vector<int> histogram_l1( N_, 0 );
    std::vector<int> histogram_l2( N_, 0 );
    Pattern x(D_, 0);
    // W_ += outer_prod((*pall_pattern_)[6],(*pall_pattern_)[6]);
    // W_ += outer_prod((*pall_pattern_)[3],(*pall_pattern_)[3]);
    W_ += embed_pattern( (*pall_pattern_)[3] );
    W_ += embed_pattern( (*pall_pattern_)[6] );

    for (size_t i=0; i < W_.size1(); ++i){ W_(i,i) = 0.0; }

    for (size_t i=0; i < W_.size1(); ++i){
      for (size_t j=0; j < W_.size2(); ++j){
	std::cout << "[" << W_(i,j) << "]" << ",";
      }
      std::cout << std::endl;
    }

    for (size_t t = 0; t < l1; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin()+1, x.end()-1);
      std::cout << "x = " << x << "\tn=" << n << std::endl;
      histogram_l1[n]++;
    }

    std::copy(histogram_l1.begin(), histogram_l1.end(),
	      std::ostream_iterator<int>(std::cout,"\t"));

    x = Pattern(D_, 0);
    for (size_t t = 0; t < l2; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin()+1, x.end()-1);
      histogram_l2[n]++;
    }

    fprintf(fp, "#x^n\t boltzmann\t l1=%d \t l2=%d\n", l1, l2);
    for(size_t n=0; n < N_; n++){
      fprintf(fp, "%d\t %lf\t %lf\t %lf\n",
	      n,
	      boltzmann_distribution(W_, (*pall_pattern_)[n]),
	      static_cast<double>(histogram_l1[n])/static_cast<double>(l1),
	      static_cast<double>(histogram_l2[n])/static_cast<double>(l2));
    }
    fclose(fp);

    fp = fopen("dir-dat/kadai2-W.dat", "w");
    for (size_t i=0; i < W_.size1(); ++i){
      for (size_t j=0; j < W_.size2(); ++j){
	fprintf(fp, "%.3lf\t", W_(i,j));
      }
      fprintf(fp,"\n");
    }
    fclose(fp);
  }
};

class Kadai4_simulation : public BoltzmannMachine1L
{
public:
  Kadai4_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution)
    : BoltzmannMachine1L(pall_pattern, T, K, D, input_pattern_distribution)
  {//                 x_0, x_1,  x_2,  x_3
    double pr_cell[]={0.0, 0.0, 0.50, 0.50};
    set_select_cell(std::vector<Probability>(1, Probability(pr_cell, pr_cell+D_)));
  }

  // const Pattern& xi = all_pattern[i];
  //       ret = ret + (1.0/(i+1.0))*( energy(W,xi) - ret);
  //       std::cout << __FUNCTION__ << ":" << __LINE__ << std::endl;
  //       std::cout << "ret = " << ret << std::endl;
  
  //                   1.0
  // Pr{x_i} = ------------------
  //             1.0 + exp(-u)

  // 
  // E(x) = - \sum_{i<j} w_{ij} x_{i} x_{j}
  // 

  //                   exp(-E(x))
  // p(x) = ---------------------------
  //         \sum_{i}{ exp(-E(x)) }

  //                                      1.0
  // p(x_n) = --------------------------------------------------------------
  //         exp(-E(x_0))    exp(-E(x_1))          exp(-E(x_2))     exp(-E(x_3))         
  //         ------------- + ------------- + ... + ------------- + ------------- 
  //         exp(-E(x_n))    exp(-E(x_n))          exp(-E(x_n))     exp(-E(x_n))  
  
  double boltzmann_distribution(const Layer& W, const Pattern& x)
  {
    double ret = 0.0;
    const std::vector<Pattern>& all_pattern = *pall_pattern_;
    size_t number_of_allpattern = all_pattern.size();
    double en = energy(W,x);
    double ei;
    for (size_t i=0; i < number_of_allpattern; ++i){
      ei   = energy(W, all_pattern[i]);
      ret += exp(en - ei);
      //std::cout << "i=" << i << "ret=" << ret << "1./ret" << 1./ret << std::endl;
    }
    return 1./ret;
  }

  void learning_rule()
  {
    const size_t n_qpattern = 1000;
    FILE* fp;
    for(size_t i=0; i < n_qpattern; ++i){
      size_t n = pRandom_select_pattern_->roll();
      Pattern& xn = (*pall_pattern_)[n];
      F_ += outer_prod( xn, xn );
    }
    for (size_t i=0; i < F_.size1(); ++i){ F_(i,i); }
    F_ /= static_cast<double>(n_qpattern);

    fp = fopen("dir-dat/kadai4-fij.dat","w");
    for(size_t i=0; i < F_.size1(); ++i){
      for(size_t j=0; j < F_.size2(); ++j){
	fprintf(fp, "%lf ", F_(i,j));
      }
      fprintf(fp, "\n");
    }
    fclose(fp);

    fp = fopen("dir-dat/kadai4-KL.dat","w");    
    Pattern x(D_, 0.0);
    for(size_t t=0; t < 100000; ++t){
      // (d)
      for(size_t k=0; k < 100; ++k){
	x = gibbs_sampling(W_, x);
	G_ += outer_prod(x, x);
      }
      G_ /= 100.0;

      // (e)
      W_ = W_ + 0.01*(F_ - G_);
      // (f)
      double kl = calc_KL_divergence();
      fprintf(fp, "%d %lf\n", t, kl);
    }
    fclose(fp);

    fp = fopen("dir-dat/kadai4-p.dat","w");
    fprintf(fp, "# x^n\t q(x)\t p(x)\n");
    for(size_t i=0; i < N_; ++i){
      fprintf(fp, "%d\t %.3lf\t %.3lf\n",
	      i,
	      input_pattern_distribution_[i],
	      boltzmann_distribution(W_, (*pall_pattern_)[i]));
    }
    fclose(fp);
  }

  void start()
  {
    learning_rule();
    FILE* fp = fopen("dir-dat/kadai4-W.dat", "w");
    for (size_t i=0; i < W_.size1(); ++i){
      for(size_t j=0; j < W_.size2(); ++j){
	fprintf(fp, "%lf\t", W_(i,j));
      }
      fprintf(fp, "\n");
    }
    fclose(fp);
    getW();
  }

  const Layer& getW()
  {
    printf("-----\n");
    for (size_t i=0; i < W_.size1(); ++i){
      for (size_t j=0; j < W_.size2(); ++j){
	printf("%lf,", W_(i,j));
      }
      printf("\n");
    }
    printf("-----");
    return W_; 
  }
};

class Kadai5_simulation : public BoltzmannMachine1L
{
public:
  Kadai5_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution,
		    const Layer& W)
    : BoltzmannMachine1L(pall_pattern, T, K, D, input_pattern_distribution)
  {
    using namespace std;
    W_ = W;
    double pr_cell[]={0.0, 0.0, 0.5, 0.5};
    set_select_cell(std::vector<Probability>(1, Probability(pr_cell, pr_cell+D_)));

    cout << __FUNCTION__ << "-" << __LINE__ << endl;
    for (size_t i=0; i < W_.size1(); ++i){
      for (size_t j=0; j < W_.size2(); ++j){
	cout << "W  = " << W (i,j)  << endl;
	cout << "W_ = " << W_(i,j) << endl;
      }
    }
    
    copy(input_pattern_distribution.begin(),
	 input_pattern_distribution.end(),
	 ostream_iterator<double>(cout, ","));
    cout << endl;
    copy(input_pattern_distribution_.begin(),
	 input_pattern_distribution_.end(),
	 ostream_iterator<double>(cout, ","));
    cout << endl;
  }

  void learning_rule()
  {
    const size_t n_qpattern = 1000;
    FILE* fp;
    for(size_t i=0; i < n_qpattern; ++i){
      size_t n = pRandom_select_pattern_->roll();
      Pattern& xn = (*pall_pattern_)[n];
      F_ += outer_prod( xn, xn );
    } 
    for (size_t i=0; i < F_.size1(); ++i){ F_(i,i); }
    F_ /= static_cast<double>(n_qpattern);
    
    fp = fopen("dir-dat/kadai5-fij.dat","w");
    for(size_t i=0; i < F_.size1(); ++i){
      for(size_t j=0; j < F_.size2(); ++j){
	fprintf(fp, "%lf ", F_(i,j));
      }
      fprintf(fp, "\n");
    }
    fclose(fp);

    Pattern x(D_, 0.0);
    x[0] = 1.0;
    x[1] = 1.0;
    for(size_t t=0; t < 10000; ++t){
      // (d)
      for(size_t k=0; k < 100; ++k){
	x = gibbs_sampling(W_, x);
	assert(x[0] == 1);
	assert(x[1] == 1);
	G_ += outer_prod(x, x);
      }
      for (size_t i=0; i < G_.size1(); ++i){ G_(i,i)=0.0;}
      G_ /= 100.0;
      // (e)
      W_ = W_ + 0.01*(F_ - G_);
      // (f)
    }

    fp = fopen("dir-dat/kadai5-px1.dat","w");
    for (size_t i=0; i < N_; ++i){
      fprintf(fp, "%d %lf\n", i,
	      boltzmann_distribution(W_, (*pall_pattern_)[i]));
    }
    fclose(fp);

    fp = fopen("dir-dat/kadai5-W.dat","w");
    for (size_t i=0; i < W_.size1(); ++i){
      for (size_t j=0; j < W_.size2(); ++j){
	fprintf(fp, "%lf ", W_(i,j));
      }
      fprintf(fp, "\n");
    }
    fclose(fp);
  }

  void start()
  {
    learning_rule();
    FILE* fp = fopen("dir-dat/kadai5.dat", "w");
    for (size_t i=0; i < W_.size1(); ++i){
      for(size_t j=0; j < W_.size2(); ++j){
	fprintf(fp, "%lf\t", W_(i,j));
      }
      fprintf(fp, "\n");
    }
    fclose(fp);
  }
};

int main(int argc, char** argv)
{
  const size_t degree = 4;
  const size_t n_allpattern = 0x01 << (degree-1);
  const TimeOfRepeat T( 1000000 );
  const KstepGibbsSampling K( 1 );
  const DegreeOfVisibleVector D( degree );
  const NumberOfAllPattern N( n_allpattern );

  Probability input_pattern_distribution( n_allpattern, 1.0/n_allpattern );
  std::vector<Pattern> all_pattern( n_allpattern , Pattern( degree, 0 ));
  std::ofstream ofs("dir-dat/all_pattern.dat");
  for(size_t i=0; i < n_allpattern; ++i){
    Pattern& x = all_pattern[i];
    x[0] = 1;
    dtob<Pattern::iterator>(i, x.begin()+1, x.end()-1);
    ofs << "i=" << i << "x=" << all_pattern[i]
	<< "d=" << btod<Pattern::iterator>( x.begin()+1, x.end()-1)
	<< std::endl;
  } 

  Kadai1_simulation sim1(&all_pattern, T, K, D, input_pattern_distribution);
  sim1.start();
  Kadai23_simulation sim23(&all_pattern, T, K, D, input_pattern_distribution);
  sim23.start();

 //  double qtbl4[n_allpattern] = {0.1, 0.1, 0.05, 0.05, 0.1, 0.1, 0.4, 0.1};
//   std::copy(qtbl4, qtbl4 + n_allpattern, input_pattern_distribution.begin());
//   Kadai4_simulation sim4(&all_pattern, T, K, D, input_pattern_distribution);
//   sim4.start();
//   //double qtbl5[n_allpattern] = {0.0, 0.0, 0.0, 0.0, 0.142, 0.142, 0.571, 0.142};
//   //std::copy(qtbl5, qtbl5 + n_allpattern, input_pattern_distribution.begin());
//   double pr_cell[degree] = {0.0, 0.0, 0.5, 0.5};
//   std::vector<Probability> Pr_cell(1, Probability(pr_cell,pr_cell+degree));
//   Kadai5_simulation sim5(&all_pattern, T, K, D,
// 			 input_pattern_distribution, sim4.getW());
//   sim5.set_select_cell(Pr_cell);
//   sim5.start();

  return 0;
}
