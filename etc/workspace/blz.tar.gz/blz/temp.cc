template<typename T>T
partition_function(const dMatrix& Theta_) const
{
    int i,j,n;
    T z = 0.0;
    for(n=0; n < N_; n++){
      const iVector& x = xs_[n];
      z += exp(-eq4<T>(x));
    }
    assert(z > 0.0);
    return z;
}
  
// probability p(x)
template<typename T>T
eq3(const iVector& x) const
{
    T c = 1./partition_function<T>(W_);
    T y = c*exp(-eq4<T>(x));
    assert(c > 0 && c <= DBL_MAX);
    //assert(y >= 0.0 && y <= 1.0);
    if(!(y >= 0.0 && y <= 1.0)){
      std::cout << "error occured" << std::endl;
      std::cout << "DBL_MAX=" << DBL_MAX  << std::endl;
      std::cout << "DBL_MIN=" << DBL_MIN  << std::endl;
      std::cout << "y = " << y  << std::endl;
      std::cout << "c = " << c  << std::endl;
      std::cout << "W_= " << W_ << std::endl;
      assert(y >= 0.0 && y <= 1.0);
    }
    return y;
}
  
  
template<typename T>T
eq4(const iVector& x) const
{
    int i, j;
    T energy = 0.0;

    for(j=0; j < D_; j++){
      for(i=0; i < j; i++){
  	energy += W_(i,j)*x(i)*x(j);
      }
    }
#if DENERGY == 1
    T max_energy = 0.0;
    T min_energy = 0.0;
    for(int j=0; j < D_; j++){
      for(int i=0; i < j; i++){
	if (W_(i,j) >= 0){ max_energy += W_(i,j); }
	else { min_energy += W_(i,j); }
      }
    }
    std::cout << "max_energy =" << max_energy << std::endl;
    std::cout << "min_energy =" << min_energy << std::endl;
#endif
    return -energy;
}
