#include <iostream>
#include <iterator>
#include <functional>
#include <algorithm>
#include <boost/bind.hpp>
#include <boost/ref.hpp>

using namespace std;

class B
{
public:
  double f(double x) const
  {
    return -x;
  }
  double f(double x, double y) const
  {
    return x + y;
  }
};

#define SIZE 8

int main()
{
  double x[SIZE] = {1,2,3,4,5,6,7,8};
  double y[SIZE];
  double const& (B::*f)(double,double) const = &B::f;
  transform(x, x+SIZE, y, boost::bind( f, _1, 1.0));
  copy(y, y+SIZE, ostream_iterator<double>(cout,","));
  return 0;
}
