#include <string>
#include <cstring>
#include <algorithm>
#include <numeric>
#include <iterator>
#include <initializer_list>
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/TestAssert.h>
#include <cppunit/TestCase.h>
#include <cppunit/TestResult.h>
#include <cppunit/TestSuite.h>
#include <cppunit/TestCaller.h>
#include "BoltzmannMachine.hpp"
#include "Pattern.hpp"
//class BoltzmannMachine;
//class Pattern;

using namespace CppUnit;

static int count_onbit(const Pattern& pattern)
{
  const double delta = 0.01;
  int ret = 0;
  for(size_t i=0; i < pattern.size(); i++){
    ret += (1.0 > pattern[i] - delta  &&
	    1.0 < pattern[i] + delta)  ? 1 : 0;
  }
  return ret;
}

// static int dtob(int src, Pattern& dst)
// {
//   for (size_t i = 0; i < dst.size(); i++){
//     dst[i] = (src >> i)&0x01; 
//   }
//   return src;
// }

double func_expection(double *prob, int size)
{
  double expection = 0.0;
  for (int x=0; x < size; x++){
    expection += x*prob[x];
  }
  return expection;
}

double func_variance(double *prob, int size)
{
  double mu = func_expection( prob, size );
  double *v = new double[ size ];
  for (int x=0; x < size; x++){
    v[x] = (x - mu)*(x - mu);
  }
  double variance = 0.0;
  for (int i=0; i < size; i++){
    variance += v[i]*prob[i];
  }
  delete[] v;
  return variance;
}

double func_bin_expection(double p, double n)
{ return n*p; }

double func_bin_variance(double p, double n)
{ return n*p*(1.0 - p); }

static void func_probability_result(RollWeightedDie* pRwd,
				    int repeat,
				    int size, 
				    int *result_time,
				    double *prob_time)
{
  for (int i=0; i < repeat; i++){
    result_time[pRwd->roll()]++;
  }
  for (int i=0; i < size; i++){
    prob_time[i] 
      = static_cast<double>( result_time[i] )
      / static_cast<double>( repeat         );
  }
}

static void func_probability_result(RollWeightedDie* pRwd,
				    int trial,
				    int size, 
				    std::vector<int>& count, 
				    Probability& prob)
{
  for (int i=0; i < trial; i++){
    count[pRwd->roll()]++;
  }
  for (int i=0; i < size; i++){
    prob[i]
      = static_cast<double>( count[i] )
      / static_cast<double>(    trial );
  }
}

class BoltzmannMachineTest : public TestCase
{
  enum {
    DIMENSION	 = 8,
    N_ALLPATTERN = 0x01 << DIMENSION, 
    TIME	 = 10, 
    KSTEP	 = 1
  };

  BoltzmannMachine *pblz1_, *pblz2_, *pblz3_;
  std::vector<Pattern> all_pattern_;

  TimeOfRepeat		T_;
  KstepGibbsSampling	K_;
  DegreeOfVisibleVector	D_;
public:
  BoltzmannMachineTest();
  void setUp();
  void tearDown();
  void test_dtob();
  void test_sigmoid();
  void test_gibbs_sampling();
  void test_partition_function();
  void test_KL_divergence();
  void test_rand_select_cell();
  void test_set_select_cell();
  void test_BoltzmannDistribution();
  void test_energy();
  void test_learn();

  static Test *suite()
  {
    TestSuite *suiteOfTests = new TestSuite;
    
    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_dtob"),
			     &BoltzmannMachineTest::test_dtob));
    
    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_sigmoid"),
			     &BoltzmannMachineTest::test_sigmoid));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_gibbs_sampling"),
			     &BoltzmannMachineTest::test_gibbs_sampling));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_partition_function"),
			     &BoltzmannMachineTest::test_partition_function));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_KL_divergence"),
			     &BoltzmannMachineTest::test_KL_divergence));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_rand_select_cell"),
			     &BoltzmannMachineTest::test_rand_select_cell));
    
    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_set_select_cell"),
			     &BoltzmannMachineTest::test_set_select_cell));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_BoltzmannDistribution"),
			     &BoltzmannMachineTest::test_BoltzmannDistribution));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_energy"),
			     &BoltzmannMachineTest::test_energy));

    suiteOfTests->addTest (new TestCaller<BoltzmannMachineTest>
			   ( std::string("test_learn"),
			     &BoltzmannMachineTest::test_learn));
    return suiteOfTests;
  }
};

BoltzmannMachineTest::BoltzmannMachineTest()
  : all_pattern_(N_ALLPATTERN, Pattern(DIMENSION)),T_(TIME), K_(KSTEP), D_(DIMENSION)
{
  for (size_t i=0; i < all_pattern_.size(); i++){
    Pattern &xi = all_pattern_[i];
    dtob<Pattern::iterator>(i, xi.begin()+1, xi.begin()+D_.data_-1);
  }
}

void BoltzmannMachineTest::setUp()
{
  int dimenstion = D_.data_;
  std::vector<double> input_pattern_distribution(dimenstion);
  std::fill(input_pattern_distribution.begin(),
	    input_pattern_distribution.end()  ,
	    1./static_cast<double>(dimenstion));

  pblz1_ = new BoltzmannMachine1L(&all_pattern_,T_,K_,D_,
				  input_pattern_distribution);

  pblz2_ = new BoltzmannMachine1L_threshold(&all_pattern_,T_,K_,D_,
					    input_pattern_distribution,
					    Threshold(dimenstion, 0.0));
  
  pblz3_ = new BoltzmannMachine1L_threshold(&all_pattern_,T_,K_,D_,
					    input_pattern_distribution,
					    Threshold(dimenstion, 0.1));
}

void BoltzmannMachineTest::tearDown()
{
  delete pblz1_;
  delete pblz2_;
  delete pblz3_;
}

void BoltzmannMachineTest::test_dtob()
{
  int D = 4;
  std::vector<Pattern> all_pattern(0x01<<(D-1), Pattern(D, 0));
  std::vector<int> a_iter(0x01<<(D-1), 0);
  std::vector<int> a_btod(0x01<<(D-1), 0);
  for (size_t i=0; i < all_pattern.size(); ++i){
    Pattern& xi = all_pattern[i];
    dtob<Pattern::iterator>(i, xi.begin(), xi.begin()+D-1);
    a_btod[i] = btod<Pattern::iterator>(xi.begin(), xi.begin()+D-1);
    a_iter[i] = i;
  }

  for (size_t i=0; i < a_btod.size(); ++i){
    std::cout << "all_pattern["<< i <<"]=" << all_pattern[i] << "\t";
    std::cout << "a_btod["<< i <<"]=" << a_btod[i] << "\t";
    std::cout << "a_iter["<< i <<"]=" << a_iter[i] << std::endl;
  }

  CPPUNIT_ASSERT(a_btod[0] == a_iter[0]);
  CPPUNIT_ASSERT(a_btod[1] == a_iter[1]);
  CPPUNIT_ASSERT(a_btod[2] == a_iter[2]);
  CPPUNIT_ASSERT(a_btod[3] == a_iter[3]);
  CPPUNIT_ASSERT(a_btod[4] == a_iter[4]);
  CPPUNIT_ASSERT(a_btod[5] == a_iter[5]);
  CPPUNIT_ASSERT(a_btod[6] == a_iter[6]);
  CPPUNIT_ASSERT(a_btod[7] == a_iter[7]);
}

void BoltzmannMachineTest::test_sigmoid()
{
  const double delta      = 0.01;
  const double dimenstion = D_.data_;
  int count = 0;
  //CPPUNIT_ASSERT_DOUBLES_EQUAL(expedted, actual, delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(0.268, pblz1_->sigmoid(-1.0), delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(0.500, pblz1_->sigmoid( 0.0), delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(0.731, pblz1_->sigmoid( 1.0), delta);
  Pattern xt( dimenstion );
  FILE* fp = fopen("sigmoid.test","w");
  for(int i = 1; i < dimenstion; i++){
    int n = (0x01 << i) - 1;
    dtob<Pattern::iterator>(n, xt.begin(), xt.end()-1);
    count = count_onbit(xt);
    fprintf(fp, "%d %lf\n", i, pblz1_->sigmoid( count ));
  }
  fclose(fp);
}

void BoltzmannMachineTest::test_rand_select_cell()
{
  std::cout << "test_rand_select_cell" << std::endl;
  const int n = 1000000;
  const int d = D_.data_;
  std::vector<int> count(d, 0.0);
  Probability actual(d, 0.0);	// sample mean value
  double delta = 0.0;	// sample variance
  Probability expection(d, 1.0/static_cast<double>(d));

  func_probability_result(pblz1_->pRandom_select_cell_,
			  n, d, count, actual);
  double Xbar 
    = std::accumulate( actual.begin(), actual.end(), 0.0 )
    / static_cast<double>( actual.size() );
  
  for (size_t i=0; i < actual.size(); i++){
    delta += (actual[i] - Xbar)*(actual[i] - Xbar);
    std::cout << "delta = " << delta << std::endl;
    std::cout << "Xbar = " << Xbar << std::endl;
  }
  delta /= static_cast<double>(actual.size());
  
  for (int i=0; i < d; i++){
    std::cout << "expection[" << i     << "]=" << expection[i] << "\t";
    std::cout << "actual["    << i     << "]=" <<    actual[i] << "\t";
    std::cout << "delta ="    << delta << "\t";
    std::cout << "count["     << i     << "]=" <<     count[i] << std::endl;
  }
  
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[0], actual[0], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[1], actual[1], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[2], actual[2], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[3], actual[3], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[4], actual[4], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[5], actual[5], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[6], actual[6], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[7], actual[7], delta);
}

void BoltzmannMachineTest::test_set_select_cell()
{
  std::cout << "test_set_select_cell" << std::endl;
  const int n = 1000000;
  const int d = D_.data_;
  Probability expection( d, 1.0/static_cast<double>(d));
  Probability actual( d, 0.0 );
  std::vector<int> count( d, 0 );
  double delta = 0.0;
  std::vector<Probability> probabilities(1, expection);
  pblz1_->set_select_cell(probabilities);
  func_probability_result(pblz1_->pRandom_select_cell_, n, d, count, actual);

  double Xbar 			// sample variance
    = std::accumulate( actual.begin(), actual.end(), 0.0 )
    / static_cast<double>( actual.size() );
  for (size_t i=0; i < actual.size(); i++){
    delta += (actual[i] - Xbar)*(actual[i] - Xbar);
    std::cout << "delta = " << delta << std::endl;
    std::cout << "Xbar = " << Xbar << std::endl;
  }
  delta /= actual.size();

  for (int i=0; i < d; i++){
    std::cout << "expection[" << i     << "]=" << expection[i] << "\t";
    std::cout << "actual["    << i     << "]=" <<    actual[i] << "\t";
    std::cout << "delta = "   << delta << "\t";
    std::cout << "count["     << i     << "]=" <<     count[i] << std::endl;
  }

  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[0], actual[0], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[1], actual[1], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[2], actual[2], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[3], actual[3], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[4], actual[4], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[5], actual[5], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[6], actual[6], delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(expection[7], actual[7], delta);
}

static int hamming_distance(const Pattern& p1, const Pattern& p2)
{
  assert(p1.size() == p2.size());
  const double delta = 0.1;
  int count = 0;
  size_t size = p1.size();
  for (size_t i = 0; i < size; i++){
    count += (p1[i] > p2[i] - delta   &&
	      p1[i] < p2[i] + delta )  ? 1 : 0;
  }
  return count;
}

void BoltzmannMachineTest::test_gibbs_sampling()
{
  size_t dimenstion = D_.data_;
  const size_t test_count = 40;
  Pattern xt(dimenstion), xt1(dimenstion);
  int counts[test_count]; std::fill(counts, counts + test_count, 0);
  int K[test_count] = {
    10, 11, 12, 13, 14, 15, 16, 17, 18, 19,
    20, 21, 22, 23, 24, 25, 26, 27, 28, 29,
    30, 31, 32, 33, 34, 35, 36, 37, 38, 39,
    40, 41, 42, 43, 44, 45, 46, 47, 48, 49,
  };
  
  Layer W(dimenstion, dimenstion);
  for (size_t i=0; i < dimenstion; i++){
    for (size_t j=0; j < dimenstion; j++){
      W(i,j) = 0.00;
    }
  }

  FILE *fp = fopen("gibbs_sampling.test", "w");
  // tests loop
  for(size_t i=0; i < test_count; i++){
    std::fill(xt .begin(), xt .end(), 0.0);
    std::fill(xt1.begin(), xt1.end(), 0.0);
    pblz1_->K_ = K[i];
    xt1 = pblz1_->gibbs_sampling(W,xt);
    counts[i] = hamming_distance(xt,xt1);
    //print_pattern(fp, xt1);
    fprintf(fp, "%d", counts[i]);
  }
  fclose(fp);
}

void BoltzmannMachineTest::test_partition_function()
{  
  std::cout << "**************** test_partition_function ****************" << std::endl;
  std::cout << pblz1_->partition_function(
					  dynamic_cast<BoltzmannMachine1L*>(pblz1_)->W_,
					  all_pattern_) << std::endl;
  std::cout << pblz2_->partition_function(
					  dynamic_cast<BoltzmannMachine1L*>(pblz2_)->W_,
					  all_pattern_) << std::endl;
  std::cout << pblz3_->partition_function(
					  dynamic_cast<BoltzmannMachine1L*>(pblz3_)->W_,
					  all_pattern_) << std::endl;
  CPPUNIT_ASSERT(false);
}

void BoltzmannMachineTest::test_KL_divergence()
{
  const int	dimension = 4;
  const double	delta	  = 0.0001;
  double	result1, result2;
  double P_tbl[][dimension] = {
    {0.250, 0.250, 0.250, 0.250}
  };
  double Q_tbl[][dimension] = {
    {0.250, 0.250, 0.250, 0.250},	// <= D_KL(P||Q) = 0
    {0.300, 0.300, 0.200, 0.200},
    {0.300, 0.300, 0.300, 0.100},
  };
  
  Probability P_0(P_tbl[0], P_tbl[0] + dimension);
  Probability Q_0(Q_tbl[0], Q_tbl[0] + dimension);
  Probability Q_1(Q_tbl[1], Q_tbl[1] + dimension);
  Probability Q_2(Q_tbl[2], Q_tbl[2] + dimension);

  result1 = pblz1_->KL_divergence(P_0, Q_0);
  result2 = pblz1_->KL_divergence(Q_0, P_0);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(0.000, result1, delta);
  CPPUNIT_ASSERT_DOUBLES_EQUAL(0.000, result2, delta);
  
  result1 = pblz1_->KL_divergence(P_0, Q_1);
  result2 = pblz1_->KL_divergence(P_0, Q_2);
  CPPUNIT_ASSERT(result1 < result2);

  result1 = pblz1_->KL_divergence(P_0, Q_1);
  result2 = pblz1_->KL_divergence(Q_1, P_0);
  CPPUNIT_ASSERT(result1 != result2);
}

void BoltzmannMachineTest::test_BoltzmannDistribution()
{
  CPPUNIT_ASSERT(false);
}

void BoltzmannMachineTest::test_energy()
{
  size_t dimention = 4;
  size_t number_of_allpattern = 0x01 << dimention;
  Layer W(dimention, dimention);
  std::vector<Pattern> xn(number_of_allpattern, Pattern(dimention));
  std::vector<double> result1(number_of_allpattern);
  std::vector<double> result2(number_of_allpattern);

  for (size_t i=0; i < dimention; i++){
    for (size_t j=0; j < dimention; j++){
      W(i,j) = 1.0;
    }
    W(i,i)=0.0;
  }
  
  for (size_t i=0; i < dimention; i++){
    for (size_t j=0; j < dimention; j++){
      std::cout << W(i,j) << ",";
    }
    std::cout << std::endl;
  }

  for (size_t i=0; i < number_of_allpattern; i++){
    dtob<Pattern::iterator>(i,xn[i].begin(), xn[i].end()-1);
    result1[i] = pblz1_->energy (W,xn[i]);
    result2[i] = pblz1_->energy2(W,xn[i]);
    std::cout << xn[i] << "\t";
    std::cout << "result1[" << i << "]="<< result1[i] << "\t";
    std::cout << "result2[" << i << "]="<< result2[i] << std::endl;
  }
}

void BoltzmannMachineTest::test_learn()
{
  CPPUNIT_ASSERT(false);
}


int main(int argc, char* argv[])
{
  //CppUnit::TestSuite  suite ;
  TestResult result;
  TextUi::TestRunner runner;
  runner.addTest (BoltzmannMachineTest::suite ());
  runner.run();
  //runner.run ( result );
  return 0;
}
