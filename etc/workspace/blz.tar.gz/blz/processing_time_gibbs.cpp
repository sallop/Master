#include <iostream>
#include <cstring>
#include <ctime>
#include <sys/time.h>
#include "BoltzmannMachine.hpp"

using namespace std;

void dtob(int src, Pattern& dst)
{
  for (size_t i=0; i < dst.size(); i++)
    dst[i] = (src >> i) & 0x01;
}

template<size_t T>
void dtob(int src, double dst[T])
{
  for (size_t i=0; i < T; i++)
    dst[i] = static_cast<double>((src >> i) & 0x01);
}

double gettimeofday_sec()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}


int main(int argc, char** argv)
{
  int degree = atoi(argv[1]);
  int number_of_allpattern = 0x01 << degree;
  const size_t time = 16;	// 10^4 pattern
  TimeOfRepeat T(time);
  KstepGibbsSampling K(1);
  DegreeOfVisibleVector D(degree);
  std::vector<Pattern> all_pattern(number_of_allpattern, Pattern(degree));
  double t1,t2;
  Pattern x(degree, 0);
  Probability input_pattern_distribution( number_of_allpattern,
					  1.0/static_cast<double>( number_of_allpattern ));


  for (int i=0; i < number_of_allpattern; i++){
    dtob(i, all_pattern[i]);
  }

  BoltzmannMachine *pblz0 = new BoltzmannMachine1L( &all_pattern,
						    T,
						    K,
						    D,
						    input_pattern_distribution );
  BoltzmannMachine *pblz1 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 0.0) );

  BoltzmannMachine *pblz2 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 1.0) );

  BoltzmannMachine *pblz3 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 2.0) );
  Layer W(degree, degree);
  for (int i=0; i < degree; i++){
    for (int j=0; j < degree; j++){
      W(i,j) = 0.1;
    }
  }

  t1 = gettimeofday_sec();
  for (size_t i=0; i < time; i++){
    x = pblz0->gibbs_sampling(W,x);
    std::cout << x << std::endl;
  }
  t2 = gettimeofday_sec();
  std::cout << degree << "\t" << t2 - t1 << std::endl;

  cout << "pblz0=" << pblz0->energy(W,x) << endl;
  cout << "pblz1=" << pblz1->energy(W,x) << endl;

  cout << "pblz0 = " << pblz0->partition_function(W,all_pattern) << endl;
  cout << "pblz1 = " << pblz1->partition_function(W,all_pattern) << endl;
  cout << "pblz2 = " << pblz2->partition_function(W,all_pattern) << endl;
  cout << "pblz3 = " << pblz3->partition_function(W,all_pattern) << endl;
  
  return 0;
}
