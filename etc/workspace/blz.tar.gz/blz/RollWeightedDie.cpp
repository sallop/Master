#include <cmath>
#include <cfloat>
#include <cstdlib>
#include <cassert>
#include <time.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <vector>
#include <functional>
#include <numeric>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/variate_generator.hpp>
#include "RollWeightedDie.hpp"

boost::mt19937 gen;
//#define DEBUG
#ifdef DEBUG
# define PASS std::cout << __FUNCTION__ << __LINE__ << std::endl;
#else
# define PASS
#endif

RollWeightedDie::RollWeightedDie(const std::vector<double>& prob)
  : N_( prob.size() ), prob_( prob )
{
#ifdef DEBUG
  std::cout << "N_ = " << N_ << std::endl;
  for(size_t i = 0; i < N_; i++){
    std::cout << "prob[" << i << "]=" << prob_[i] << std::endl;
  }
#endif
  assert (NULL != &prob_);
  assert (0 != N_);
  const double delta = 0.001;
  double sum = std::accumulate(prob_.begin(), prob_.end(), 0.0);
#ifdef DEBUG
  if (sum > 1.0 - delta && sum < 1.0 + delta){
    std::cout << "normal probability" << std::endl;
  } else {
    std::cout << "unnormalized probability" << std::endl;
  }
#endif
}

RollWeightedDie::RollWeightedDie(double *prob, size_t size) 
  : N_( size ), prob_( size )
{
  std::copy( prob, prob + size, prob_.begin());
  const double delta = 0.001;
  double sum = std::accumulate(prob_.begin(), prob_.end(), 0.0);
  assert (NULL != &prob_);
  assert (0 != N_);
#ifdef DEBUG
  PASS;
  std::cout << "N_ = " << N_ << std::endl;
  if (sum > 1.0 - delta && sum < 1.0 + delta){
    std::cout << "normal probability" << std::endl;
  } else {
    std::cout << "unnormalized probability" << std::endl;    
  }
#endif
}

int RollWeightedDie::roll()
{
  std::vector<double> cumulative; // 累積する
  std::partial_sum(prob_.begin(),
		   prob_.end()  ,
		   std::back_inserter(cumulative));
  boost::uniform_real<> dist(0, cumulative.back());
  boost::variate_generator<boost::mt19937&, boost::uniform_real<> >
    die(gen, dist);
  return
    (std::lower_bound(cumulative.begin(),
		      cumulative.end()  ,
		      die()) - cumulative.begin());
}
