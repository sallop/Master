#include <stdio.h>

int main()
{
  int l, m, n;

  m = 0x00;
  l = 0x01;

  printf("l     =%d\n", l     );
  printf("l^0x01=%d\n", l^0x01);
  printf("m     =%d\n", m     );
  printf("m^0x01=%d\n", m^0x01);
  return 0;
}
