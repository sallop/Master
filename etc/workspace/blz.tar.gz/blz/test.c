#include <stdio.h>

double square(double x){  return x*x; }

int main(int argc, char *argv[])
{
  double x[] = {0, 1, 2, 3, 4, 5, 6, 7};
  double pr[]= {0.125, 0.125, 0.125, 0.125,
		   0.125, 0.125, 0.125, 0.125 };
  double mu  = 3.5;
  double sum = 0.0;
  int i;

  for (i=0; i < 8; i++){
    double temp;
    temp = square(x[i] - mu)*pr[i];
    sum += temp;
    printf("(%lf-%lf)^2*%lf = %lf\n", x[i], mu, pr[i], temp);
  }
  printf("expection = %lf\n", sum);

  return 0;
}
