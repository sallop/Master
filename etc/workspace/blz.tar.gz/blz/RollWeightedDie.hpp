#ifndef __INCLUDE_ROLLWEIGHTDIE_HPP__
#define __INCLUDE_ROLLWEIGHTDIE_HPP__

#include <vector>

class RollWeightedDie
{
  size_t N_;  
  std::vector<double> prob_;
public:
  RollWeightedDie(const std::vector<double>& prob);
  RollWeightedDie(double *prob, size_t size);
  int roll();
  friend class RollWeightedDieTest;
};


#endif	// __INCLUDE_ROLLWEIGHTDIE_HPP__
