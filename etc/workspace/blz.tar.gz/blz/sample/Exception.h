#include <exception>

class Exception : public std::exception
{
 public:
 Exception(void) : exception()
    {
    }
  ~Exception(void)
    {
    }
};


void se_translator(unsigned int code)
{
  throw Exception();
}
