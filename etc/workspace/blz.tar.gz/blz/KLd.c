#include <stdio.h>
#include <math.h>


double KL1(double *P, double *Q, int size)
{
  int i;
  double d = 0.0;
  for (i=0; i < size; i++){
    d += P[i]*log(P[i]/Q[i]);
  }
  return d;
}

double KL2(double *P, double *Q, int size)
{
  int i;
  double d = 0.0;
  for (i=0; i < size; i++){
    d += P[i]*(log(P[i]) - log(Q[i]));
  }
  return d;
}

int main(int argc, char** argv)
{
  double P[]={0.30, 0.30, 0.40};
  double Q[]={0.20, 0.20, 0.60};

/*   double P[]={0.10, 0.10, 0.10, 0.10, 0.10, 0.50}; */
/*   double Q[]={0.20, 0.20, 0.20, 0.20, 0.15, 0.05}; */
  int i, j;
  double kl1, kl2;

  kl1 = KL1(P, Q, sizeof(P)/sizeof(P[0]));
  kl2 = KL2(P, Q, sizeof(P)/sizeof(P[0]));  
  printf("D_KL1(P||Q) = %lf\n", kl1);
  printf("D_KL2(P||Q) = %lf\n", kl2);

  kl1 = KL1(Q, P, sizeof(P)/sizeof(P[0]));
  kl2 = KL2(Q, P, sizeof(P)/sizeof(P[0]));  
  printf("D_KL1(Q||P) = %lf\n", kl1);
  printf("D_KL2(Q||P) = %lf\n", kl2);
  return 0;
}
