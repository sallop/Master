#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/TestAssert.h>
#include <cppunit/TestCase.h>
#include <cppunit/TestResult.h>
#include <cppunit/TestCaller.h>
#include "RollWeightedDie.hpp"
#include <cmath>
#include <string>
#include <vector>
#include <numeric>

using namespace CppUnit;

class RollWeightedDieTest : public TestCase
{
  RollWeightedDie* pRwd1_;
  RollWeightedDie* pRwd2_;
  RollWeightedDie* pRwd3_;
public:
  void setUp()
  {
  }
  
  void tearDown()
  {
  }
  
  void test_RollWeightedDie_dvector()
  {
    size_t D_ = 8;
    std::vector<double> prob(D_);
    pRwd1_ = new RollWeightedDie( prob );
    CPPUNIT_ASSERT(&pRwd1_->prob_ != &prob);
    CPPUNIT_ASSERT(prob.size() == pRwd1_->prob_.size());
    CPPUNIT_ASSERT(prob.size() == pRwd1_->N_          );
    CPPUNIT_ASSERT(         D_ == pRwd1_->N_          );
    CPPUNIT_ASSERT(prob[0] == pRwd1_->prob_[0]);
    CPPUNIT_ASSERT(prob[1] == pRwd1_->prob_[1]);
    CPPUNIT_ASSERT(prob[2] == pRwd1_->prob_[2]);
    CPPUNIT_ASSERT(prob[3] == pRwd1_->prob_[3]);
    CPPUNIT_ASSERT(prob[4] == pRwd1_->prob_[4]);
    CPPUNIT_ASSERT(prob[5] == pRwd1_->prob_[5]);
    CPPUNIT_ASSERT(prob[6] == pRwd1_->prob_[6]);
    CPPUNIT_ASSERT(prob[7] == pRwd1_->prob_[7]);
    delete pRwd1_;
  }
  
  void test_RollWeightedDie_dprob_ssize()
  {
    const size_t D_ = 8;
    double *prob = new double[D_];
    std::fill(prob, prob + D_, 1./D_);
    pRwd1_ = new RollWeightedDie(prob, D_);
    for (size_t i=0; i < D_; i++){
      std::cout << "prob[" << i << "]=" << prob[i] << std::endl;
    }

    CPPUNIT_ASSERT(&pRwd1_ != NULL);
    CPPUNIT_ASSERT(D_      == pRwd1_->prob_.size());
    CPPUNIT_ASSERT(D_      == pRwd1_->N_          );
    CPPUNIT_ASSERT(prob[0] == pRwd1_->prob_[0]);
    CPPUNIT_ASSERT(prob[1] == pRwd1_->prob_[1]);
    CPPUNIT_ASSERT(prob[2] == pRwd1_->prob_[2]);
    CPPUNIT_ASSERT(prob[3] == pRwd1_->prob_[3]);
    CPPUNIT_ASSERT(prob[4] == pRwd1_->prob_[4]);
    CPPUNIT_ASSERT(prob[5] == pRwd1_->prob_[5]);
    CPPUNIT_ASSERT(prob[6] == pRwd1_->prob_[6]);
    CPPUNIT_ASSERT(prob[7] == pRwd1_->prob_[7]);
    delete pRwd1_;
  }
  
  double expection(const std::vector<double>& Pr)
  {
    double ret=0;
    for (size_t x=0; x < Pr.size(); x++)
      {ret += x*Pr[x];}
    return ret;
  }

  double variance(const std::vector<double>& Pr)
  {
    double mu = expection(Pr);
    std::vector<double> v(Pr.size());
    std::fill(v.begin(), v.end(), 0);
    for (size_t x=0; x < Pr.size(); x++){
      v[x] = (x - mu)*(x - mu)*Pr[x];
    }
    return std::accumulate(v.begin(), v.end(), 0.0);
  }

  void test_roll()
  {
    const size_t D_ = 8;
    double repeat = 1000000;
    std::vector<double> prob(D_);
    std::vector<int>   count(D_);
    std::vector<double> result(D_);
    std::fill(prob.begin() , prob.end() , 1./D_);
    std::fill(count.begin(), count.end(), 0.0  );

    pRwd1_ = new RollWeightedDie(prob);
    for (size_t i=0; i < repeat; i++){
      int n = pRwd1_->roll();
      count[n]++;
    }
    for (size_t i=0; i < D_; i++)
      { result[i] = count[i]/repeat;}
    //    CPPUNIT_ASSERT_DOUBLES_EQUAL(expected, actual, delta);
    double e = expection(prob);
    double v =  variance(prob);
    double s =      sqrt(   v);

    std::cout << "e =" << e << std::endl;
    std::cout << "v =" << v << std::endl;
    std::cout << "s =" << s << std::endl;
    
    for (size_t i=0; i < D_; i++){
      std::cout << " prob["   << i <<"]=" << prob[i]
		<< ",result[" << i <<"]=" << result[i]
		<< ",count["  << i <<"]=" << count[i]
		<< std::endl;
    }

    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[0], result[0], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[1], result[1], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[2], result[2], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[3], result[3], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[4], result[4], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[5], result[5], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[6], result[6], s);
    CPPUNIT_ASSERT_DOUBLES_EQUAL(prob[7], result[7], s);
    delete pRwd1_;
  }
public:
  static Test *suite()
  {
    TestSuite *suiteOfTests = new TestSuite;
    suiteOfTests->addTest(new TestCaller<RollWeightedDieTest>
			  (std::string("test_RollWeightedDie(std::vector<double>& prob)"),
			   &RollWeightedDieTest::test_RollWeightedDie_dvector));
    suiteOfTests->addTest(new TestCaller<RollWeightedDieTest>
			  (std::string("test_RollWeightedDie(double prob[], size_t size)"),
			   &RollWeightedDieTest::test_RollWeightedDie_dprob_ssize));
    suiteOfTests->addTest(new TestCaller<RollWeightedDieTest>
			  (std::string("test_RollWeightedDie::roll()"),
			   &RollWeightedDieTest::test_roll));
    return suiteOfTests;
  }
};

int main(int argc, char* argv[])
{
  TestResult result;
  TextUi::TestRunner runner;
  runner.addTest (RollWeightedDieTest::suite ());
  runner.run ();
  return 0;
}
