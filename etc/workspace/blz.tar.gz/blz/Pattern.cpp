#ifndef  __INCLUDE_PATTERN__
#define __INCLUDE_PATTERN__

#include <iostream>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>

typedef boost::numeric::ublas::vector<double> Pattern;

#endif	// __INCLUDE_PATTERN__
