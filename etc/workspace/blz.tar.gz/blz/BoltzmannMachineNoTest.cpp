#include <string>
#include <cstring>
#include <cppunit/extensions/TestFactoryRegistry.h>
#include <cppunit/ui/text/TestRunner.h>
#include <cppunit/TestAssert.h>
#include <cppunit/TestCase.h>
#include <cppunit/TestResult.h>
#include <cppunit/TestSuite.h>
#include <cppunit/TestCaller.h>
#include <algorithm>
#include "BoltzmannMachine.hpp"
#include "Pattern.hpp"

class BoltzmannMachineTest
{
  BoltzmannMachine* pblz;
public:
  BoltzmannMachineTest(std::vector<Pattern>* pall_pattern,
		       TimeOfRepeat T, KstepGibbsSampling K, DegreeOfVisibleVector D,
		       std::vector<double> &input_pattern_distribution)
  {
    pblz = new BoltzmannMachine1L(pall_pattern, T, K, D, input_pattern_distribution);
  }
  void test_sigmoid(double x)
  {
    pblz->sigmoid(x);
  }
  void test_gibbs_sampling(Layer& W, Pattern& x)
  {
    pblz->gibbs_sampling(W,x);
  }
  void test_partition_function(const Layer &W, const std::vector<Pattern> &x)
  {
    pblz->partition_function(W,x);
  }
  void test_KL_divergence(const std::vector<double> &P, const std::vector<double> &Q)
  { 
    pblz->KL_divergence(P,Q);
  }
  void test_rand_select_cell()
  {
    pblz->random_select_cell();
  }
  void test_set_select_cell(std::vector<Probability>& probabilites)
  {
    pblz->set_select_cell(probabilites);
  }
  void test_set_select_pattern(std::vector<Probability>& probabilities)
  {
    pblz->set_select_pattern( probabilities );
  }

  void test_boltzmann_distribution(const Layer &W, const Pattern &x)
  {
    pblz->boltzmann_distribution(W,x);
  }

  void test_energy(const Layer &W, const Pattern &x)
  { pblz->energy(W,x);}
};

int main(int argc, char** argv)
{
  const size_t dimenstion = 10;
  const size_t number_of_allpattern = 8;
  const size_t number_of_layer = 1;
  TimeOfRepeat		T(0);
  KstepGibbsSampling	K(0);
  DegreeOfVisibleVector	D(dimenstion);

  std::vector<Pattern> all_pattern(number_of_allpattern, Pattern(dimenstion));
  std::vector<Probability> transition_cell_distribution(number_of_layer,
							Probability(dimenstion));
  Probability input_pattern_distribution(number_of_allpattern);
  std::fill(input_pattern_distribution.begin(),
	    input_pattern_distribution.end()  ,
	    1./dimenstion);
  BoltzmannMachineTest *ptest =
    new BoltzmannMachineTest(&all_pattern, T, K, D,
			     input_pattern_distribution);
  Layer W(dimenstion, dimenstion);
  Pattern x(dimenstion);
  std::vector<double> P(number_of_allpattern), Q(number_of_allpattern);
  
  ptest->test_sigmoid(0.5);
  ptest->test_gibbs_sampling(W,x);
  ptest->test_partition_function(W, all_pattern);
  ptest->test_KL_divergence(P,Q);
  ptest->test_rand_select_cell();
  ptest->test_set_select_cell(probabilities);
  ptest->test_boltzmann_distribution(W,x);
  ptest->test_energy(W,x);

  return 0;
}

