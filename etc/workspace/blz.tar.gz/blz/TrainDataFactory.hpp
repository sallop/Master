#ifndef __INCLUDE_TRAINDATAFACTORY_HPP__
#define __INCLUDE_TRAINDATAFACTORY_HPP__

#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <cstdlib>
#include <vector>
#include <iostream>
#include <algorithm>

typedef double UnitType;
typedef boost::numeric::ublas::vector<UnitType> Pattern;
typedef boost::numeric::ublas::zero_vector<UnitType> Pattern0;
typedef boost::numeric::ublas::unit_vector<UnitType> Pattern1;

#define PASS std::cout << __FUNCTION__<< " " << __LINE__ << std::endl
#define NOTIMPLIMENT std::cout << "Not Impliment " << __FUNCTION__ << __LINE__ << std::endl

class TrainDataFactory
{
protected:
  std::vector<Pattern> data_;
  std::vector<Pattern>::iterator it_;
public:
  Pattern create();
  Pattern create(int no);
  void registry();
  void registry(int* pattern, size_t size);
  void registry(Pattern pattern);
  void registry(std::vector<Pattern> patterns);
private:
  virtual Pattern createPattern();
  virtual Pattern createPattern(int no);
  virtual void registerPattern();
  virtual void registerPattern(int no);
  virtual void registerPattern(Pattern pattern);
  virtual void registerPattern(int* pattern, size_t size);
};

class ArbitararyTrainData : public TrainDataFactory
{
  int size_;
public:
  ArbitararyTrainData(int size);
private:
  Pattern createPattern();
  Pattern createPattern(int no);
  void registerPattern(int *pattern, size_t size);
  void registerPattern(Pattern pattern);
};

class RandomTrainData : public TrainDataFactory
{
  int size_;
  std::vector<double> flip_probablity;
public:
  RandomTrainData(int size);
  void setProb(int n, double prob);
  void printProb();
private:
  Pattern createPattern();
  Pattern createPattern(int no);
  void registerPattern();
  void registerPattern(int *pattern, size_t size);
  void registerPattern(Pattern pattern);
};

#endif// __INCLUDE_TRAINDATAFACTORY_HPP__
