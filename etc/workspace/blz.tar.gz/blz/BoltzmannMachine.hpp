#ifndef __INCLUDE_BOLTZMANNMACHINE__
#define __INCLUDE_BOLTZMANNMACHINE__
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <numeric>
#include <iostream>
#include <cmath>
#include "Pattern.hpp"
#include "RollWeightedDie.hpp"

//#define PASS std::cout << __FUNCTION__ << "-" << __LINE__ << std::endl
#define PASS
#define ONBIT  1
#define OFFBIT 0
typedef double UnitType;
typedef boost::numeric::ublas::vector<UnitType> Pattern;
typedef boost::numeric::ublas::matrix<UnitType> Layer  ;
typedef std::vector<double> Threshold;
typedef std::vector<double> Probability;

template<typename Iterator>
void dtob(int d, Iterator p0, Iterator pN)
{
  int n = pN - p0 + 1;
  while (n--){
    *pN-- = d & 0x01;
    d >>= 1;
  }
}

template<typename Iterator>
int btod(Iterator p0, Iterator pN)
{
  int n = 0;
  int MSB = 0x01 << (pN-p0);
  while (MSB){
    n += (*p0++)*MSB;
    MSB >>= 1;
  }
  return n;
}

// wrapper class
struct DegreeOfVisibleVector
{
  int data_;
  DegreeOfVisibleVector(int data) : data_(data){}
};

struct NumberOfAllPattern
{
  int data_;
  NumberOfAllPattern(int data) : data_(data){}
};

struct TimeOfRepeat
{
  int data_;
  TimeOfRepeat(int data) : data_(data){}
};

struct KstepGibbsSampling
{
  int data_;
  KstepGibbsSampling(int data) : data_(data){}
};


class BoltzmannMachine
{
protected:
  RollWeightedDie	*pRandom_select_cell_;
  RollWeightedDie	*pRandom_select_pattern_;
  std::vector<Pattern>	*pall_pattern_;
  size_t		 N_;	// number of all pattern
  size_t		 T_;	// repeat time
  size_t		 K_;	// K-step gibbs sampling
public:
  BoltzmannMachine();
  BoltzmannMachine(std::vector<Pattern>         *pall_pattern,
		   const TimeOfRepeat		&T,
		   const KstepGibbsSampling	&K);
  void learn();
  void set_select_cell(const std::vector<Probability> &probabilities)
  { this->sub_set_select_cell(probabilities);}
  void set_select_pattern(const std::vector<Probability> &probabilities)
  { this->sub_set_select_pattern(probabilities);}
  //protected:  
  
  double sigmoid(double x){ return 1./(1. + exp(-x));}
  virtual double energy(const Layer &W, const Pattern &x);
  double energy2(const Layer &W, const Pattern &x);
  double partition_function(const Layer &W, const std::vector<Pattern> &patterns);
  virtual double boltzmann_distribution(const Layer &W, const Pattern &x);
  virtual Pattern gibbs_sampling(const Layer &W, Pattern x_t1);
  int random_select_cell(){ return  pRandom_select_cell_->roll();};
  int random_select_pattern(){ return  pRandom_select_pattern_->roll();};
  double KL_divergence(const Probability &P, const Probability &Q);
  virtual void cell_update(int n){ std::cout << "Not Implimented" << std::endl; }
private:
  virtual void learning_rule() = 0;
  virtual void sub_set_select_cell(const std::vector<Probability>& probabilities) = 0;
  virtual void sub_set_select_pattern(const std::vector<Probability>& probabilities) = 0;
  friend class BoltzmannMachineTest;
};

class BoltzmannMachine1L : public BoltzmannMachine
{
protected:
  Layer		W_;		// model parameter
  Layer		F_;		// data dependent expection
  Layer		G_;		// model dependent expection
  size_t	D_;		// visible vector degree
  Probability input_pattern_distribution_;
  Probability transition_cell_distribution_;
  virtual double calc_KL_divergence();
public:
  BoltzmannMachine1L(std::vector<Pattern> *pall_pattern,
		     const TimeOfRepeat		 &T,
		     const KstepGibbsSampling	 &K,
		     const DegreeOfVisibleVector &D,
		     const Probability &input_pattern_distribution,
		     const Probability &transition_cell_distribution);
private:
  void learning_rule();
  void sub_set_select_cell(const std::vector<Probability> &probabilities);
  void sub_set_select_pattern(const std::vector<Probability> &probabilities);

  friend class BoltzmannMachineTest;
  friend class BoltzmannMachine1LTest;
  //double eq3();                       => BoltzmannDistribution()
  //double eq4(const Pattern& x) const; => Energy()
};

class BoltzmannMachine1L_threshold : public BoltzmannMachine1L
{
  Threshold     h_;		// threshold parameter
public:
  BoltzmannMachine1L_threshold(std::vector<Pattern>        *pall_pattern,
			       const TimeOfRepeat          &T,
			       const KstepGibbsSampling	   &K,
			       const DegreeOfVisibleVector &D,
			       const Probability &input_pattern_distribution,
			       const Probability &transition_cell_distribution,
			       const Threshold   &h_);
  virtual double energy(const Layer &W, const Pattern& x)
  {
    assert(x.size() == h_.size());
    // E(x) = -\sum w_{ij} x_i x_j + threshold
    // E_th(x) = E(x) - threshold
    double threshold = std::inner_product(x.begin(), x.end(), h_.begin(), 0.0);
    return BoltzmannMachine::energy(W,x) - threshold;
  }
  
  friend class BoltzmannMachineTest;
  friend class BoltzmannMachine1LTest;
};

class BoltzmannMachine2L : public BoltzmannMachine
{
  Layer W1_;
  Layer W2_;
private:
  void learning_rule();
  void sub_set_select_cell(const std::vector<Probability>& probabilities);
  void sub_set_select_pattern(const std::vector<Probability>& probabilities);
public:
  BoltzmannMachine2L();
  friend class BoltzmannMachineTest;
  friend class BoltzmannMachine2LTest;
};

class BoltzmannMachine3L : public BoltzmannMachine
{
  Layer W1_;
  Layer W2_;
  Layer W3_;
public:
  BoltzmannMachine3L();
private:
  void learning_rule();
  void sub_set_select_cell(const std::vector<Probability>& probabilities);
  void sub_set_select_pattern(const std::vector<Probability>& probabilities);
  friend class BoltzmannMachineTest;
  friend class BoltzmannMachine3LTest;
};

class BoltzmannMachineNL : public BoltzmannMachine
{
  std::vector<Layer> W_;
public:
  BoltzmannMachineNL();
private:
  void learning_rule();
  void sub_set_select_cell(const std::vector<Probability>& probabilities);
  void sub_set_select_pattern(const std::vector<Probability>& probabilities);
};

class LearningRule
{
  BoltzmannMachine* pblz_;
public:
  LearningRule(BoltzmannMachine* pblz) : pblz_(pblz){}
};

#endif	// __INCLUDE_BOLTZMANNMACHINE__
