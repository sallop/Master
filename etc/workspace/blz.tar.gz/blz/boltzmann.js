/* sample.js */ 

var g = 1;

function f1(){
    return 0;
}

var f2 = function(){
    return 0;
};

var foo = {};

foo.f3 = function(){
    return 0;
};

var bar = {
    C : 10,    			//constant
    f4 : function(){ return 0; },
    hello : "Hello"
};

function Baz(n){
    this.n = n;
};

Baz.prototype.f5 = function(){
    return this.n;
};

