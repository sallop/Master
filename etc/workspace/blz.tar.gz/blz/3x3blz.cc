#include <cstdio>
#include <cassert>
#include <iostream>
#include <iterator>
#include <iomanip>
#include <sstream>
#include <fstream>
#include <functional>
#include <vector>
#include <map>
#include <algorithm>
#include <boost/mem_fn.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/numeric/ublas/banded.hpp>
#include "BoltzmannMachine.hpp"

namespace ub = boost::numeric::ublas;

#define dump(x) {std::cerr << #x << "-" << __FUNCTION__ << "-" __LINE__;}


class FileName
{
  std::string ofile_prefix_;
public:
  FileName(const char* fname) : ofile_prefix_(fname)
  {}

  std::string filename(const char* id)
  {
    std::stringstream ss;
    ss << ofile_prefix_ << id << ".dat";
    return ss.str();
  }
};

void printAllPattern(std::ostream& os, const std::vector<Pattern>& AllPattern)
{
  for(size_t i=0; i < AllPattern.size(); ++i){
    os << AllPattern[i] << std::endl;
  }
}
  
template<typename T>
void printVector(std::ostream& os, const std::vector<T>& v)
{
  std::ostream_iterator<T> out_it(os, "\t");
  std::copy(v.begin(), v.end(), out_it);
}

void printPattern(std::ostream& os, const Pattern& v)
{
  std::ostream_iterator<double> out_it(os, "\t");
  std::copy(v.begin(), v.end(), out_it);
}

void printLayer(std::ostream& os, const Layer& W)
{
  for (size_t i=0; i < W.size1(); ++i){
    for (size_t j=0; j < W.size2(); ++j){
      os << W(i,j) << "\t";
    }
    os << std::endl;
  }
}

template<typename T> inline
void set_tr0(ub::matrix<T> &m)
{
  ub::diagonal_adaptor<ub::matrix<T> > tr(m);
  tr = ub::zero_matrix<T>(tr.size1());
}

template<typename T>
ub::matrix<T> add_tr0_matrix(const ub::matrix<T>& m1, const ub::matrix<T>& m2)
{
  ub::matrix<T> ret(m1);
  ret = m1 + m2;
  set_tr0<T>(ret);
  return ret;
}

class Kadai1_simulation : public BoltzmannMachine1L_threshold, public FileName
{
public:
  Kadai1_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution,
		    const Probability &transition_cell_distribution,
		    const Threshold &h,
		    const char *ofile_prefix)
    : BoltzmannMachine1L_threshold(pall_pattern, T, K, D,
				   input_pattern_distribution,
				   transition_cell_distribution,
				   h),
      FileName(ofile_prefix)
  {
    printVector<double>(std::cout, input_pattern_distribution);
    printVector<double>(std::cout, transition_cell_distribution_);
  }

  void start()
  {
    std::ofstream ofs;
    std::string fname(filename("-p").c_str());

    Pattern x(D_, 0);
    std::vector<int> histogram( N_, 0 );
    for (size_t t = 0; t < T_; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin(), x.end()-1);
      histogram[n]++;
    }
    ofs.open( filename("-p").c_str() );
    for(size_t n=0; n < histogram.size(); ++n){
	ofs << n                                                          << "\t"
	    << histogram[n]                                               << "\t"
	    << static_cast<double>( histogram[n])/static_cast<double>(T_) << "\t"
	    << std::endl;
    }
    ofs.close();
  }
};

class Kadai23_simulation : public BoltzmannMachine1L_threshold, public FileName
{
public:
  Kadai23_simulation(std::vector<Pattern> *pall_pattern,
		     const TimeOfRepeat          &T,
		     const KstepGibbsSampling    &K,
		     const DegreeOfVisibleVector &D,
		     const Probability &input_pattern_distribution,
		     const Probability &transition_cell_distribution,
		     const Threshold &h,
		     const char *ofile_prefix)
    : BoltzmannMachine1L_threshold(pall_pattern, T, K, D,
				   input_pattern_distribution,
				   transition_cell_distribution,
				   h),
      FileName(ofile_prefix)
  {
    printVector<double>(std::cout, input_pattern_distribution);
    printVector<double>(std::cout, transition_cell_distribution_);
  }
  
  Layer embed_pattern(const Pattern& x)
  {
    Layer W(x.size(), x.size());
    for (size_t i=0; i < W.size1(); ++i){
      for (size_t j=0; j < W.size2(); ++j){
	W(i,j) = (2.0*x[i] - 1.0)*(2.0*x[j] - 1.0);
      }
    }
    //    printLayer(std::cout, W);
    return W;
  }
  
  void start()
  {
    std::ofstream ofs;
    std::stringstream ss;

    const size_t l1 = 1000, l2 = 1000000;
    std::vector<int> histogram_l1(N_,0), histogram_l2(N_,0);
    Pattern x(D_, 0);
    W_ += embed_pattern( (*pall_pattern_)[3] );
    W_ += embed_pattern( (*pall_pattern_)[6] );
    set_tr0<double>(W_);//for (size_t i=0; i < W_.size1(); ++i){ W_(i,i) = 0.0; }
    printLayer(std::cout, W_);//assert(false);

    for (size_t t = 0; t < l1; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin(), x.end()-1);

      printPattern(std::cout, x);
      std::cout << "\tn = " << n << std::endl;
      histogram_l1[n]++;
    }

    printVector<int>(std::cout, histogram_l1);
    x = Pattern(D_, 0);
    for (size_t t = 0; t < l2; ++t){
      int n;
      x = gibbs_sampling(W_, x);
      n = btod<Pattern::iterator>(x.begin(), x.end()-1);
      histogram_l2[n]++;
    }

    ofs.open( filename("-p").c_str());
    ofs << "#x^n\tboltzmann\t l1 =" << l1 << ",l2 =" << l2 << std::endl;
    for(size_t n=0; n < N_; n++){
      ofs << n                                                            << "\t"
	  << boltzmann_distribution(W_,(*pall_pattern_)[n])               << "\t"
	  << static_cast<double>(histogram_l1[n])/static_cast<double>(l1) << "\t"
	  << static_cast<double>(histogram_l2[n])/static_cast<double>(l2) << "\t"
	  << std::endl;
    }
    ofs.close();

    ofs.open( filename("-W").c_str() );
    printLayer(ofs, W_);
    ofs.close();
  }
};

class Kadai4_simulation : public BoltzmannMachine1L_threshold, public FileName
{
  Probability v_;
public:
  Kadai4_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution,
		    const Probability &transition_cell_distribution,
		    const Threshold &h,
		    const char *ofile_prefix)
    : BoltzmannMachine1L_threshold(pall_pattern, T, K, D,
				   input_pattern_distribution,
				   transition_cell_distribution,
				   h),
      FileName(ofile_prefix),
      v_(D.data_)
  {// x_0,  x_1,  x_2
    printVector<double>(std::cout, input_pattern_distribution_  );
    printVector<double>(std::cout, transition_cell_distribution_);
  }


  void learning_rule()
  {
    const size_t n_qpattern = 1000;
    std::ofstream ofs;
    for(size_t i=0; i < n_qpattern; ++i){
      size_t n = pRandom_select_pattern_->roll();
      Pattern& xn = (*pall_pattern_)[n];
      F_ += outer_prod( xn, xn );
    }
    set_tr0<double>(F_);//for (size_t i=0; i < F_.size1(); ++i){ F_(i,i) = 0.0; }
    F_ /= static_cast<double>(n_qpattern);

    ofs.open( filename("-fij").c_str() );
    printLayer(ofs, F_);
    ofs.close();

    ofs.open( filename("-KL").c_str());
    Pattern x(D_, 0.0);
    for(size_t t=0; t < 100000; ++t){
      // (d)
      size_t k=0;
      for(k = 0; k < 100; ++k){
	x = gibbs_sampling(W_, x);
	G_ += outer_prod(x, x);
      }
      set_tr0<double>(G_);
      G_ /= static_cast<double>(k);
      // (e)
      W_ = W_ + 0.01*(F_ - G_);
      // (f)
      double kl = calc_KL_divergence();
      ofs << t << "\t" << kl << "\n";
    }
    ofs.close();

    ofs.open( filename("-p").c_str());
    ofs << "# x^n\t q(x)\t p(x)\n";
    for(size_t i=0; i < N_; ++i){
      ofs << i                                                << "\t"
	  << input_pattern_distribution_[i]                   << "\t"
	  << boltzmann_distribution(W_, (*pall_pattern_)[i])  << "\t"
	  << std::endl;
    }
    ofs.close();
  }

  void start()
  {
    std::ofstream ofs;
    learning_rule();
    ofs.open(filename("-W").c_str());
    printLayer(ofs, W_);
    ofs.close();
    getW();
  }

  const Layer& getW()
  {
    printLayer(std::cout, W_);
    return W_; 
  }
};

class Kadai5_simulation : public BoltzmannMachine1L_threshold, public FileName
{
  Pattern v_;			// visible pattern state

public:
  typedef std::vector<std::pair<int, double> > Constrain;
  Kadai5_simulation(std::vector<Pattern> *pall_pattern,
		    const TimeOfRepeat          &T,
		    const KstepGibbsSampling    &K,
		    const DegreeOfVisibleVector &D,
		    const Probability &input_pattern_distribution,
		    const Probability &transition_cell_distribution,
		    const Layer &W,
		    const Threshold &h,
		    //const Constrain &constrain,
		    const char *ofile_prefix)
    : BoltzmannMachine1L_threshold(pall_pattern, T, K, D,
				   input_pattern_distribution,
				   transition_cell_distribution, h),
      FileName(ofile_prefix), v_(D_,0)
  {
    W_ = W;
    set_tr0<double>(W_);//for (size_t i=0; i < W_.size1(); ++i){ W_(i,i) = 0.0; }

    std::vector<double> vhist(N_, 0);
    for (size_t i=0; i < 10000; ++i){
      v_ = (*pall_pattern)[ random_select_pattern() ];
      int n = btod<Pattern::iterator>(v_.begin(), v_.end()-1);
      vhist[n]++;
    }
    for (size_t i=0; i < vhist.size(); i++){ vhist[i]/=10000; }

    std::vector<double> hist(3, 0);
    for (size_t i=0; i < 100; ++i){
      hist[ random_select_cell() ]++;
    }
    for (size_t i=0; i < hist.size(); i++){ hist[i]/=100; }
    
    std::cout << "vhist="; printVector<double>(std::cout, vhist);
    std::cout << "hist ="; printVector<double>(std::cout,  hist);
  }

  void learning_rule()
  {
    const size_t n_qpattern = 1000;
    std::ofstream ofs;

    for(size_t i=0; i < n_qpattern; ++i){
      Pattern& xn = (*pall_pattern_)[ random_select_pattern() ];
      F_ += outer_prod( xn, xn );
    } 
    set_tr0<double>(F_);
    F_ /= static_cast<double>( n_qpattern );
    
    ofs.open(filename("-fij").c_str());
    printLayer(ofs, F_);
    ofs.close();

    for(size_t t=0; t < 10000; ++t){
      // (d)
      size_t kmax = 100;
      for(size_t k=0; k < kmax; ++k){
	v_ = gibbs_sampling(W_, v_);
	assert(v_[0] == 1);
	G_ += outer_prod(v_, v_);
      }
      set_tr0<double>(G_);
      G_ /= static_cast<double>(kmax);
      // (e)
      W_ = W_ + 0.01*(F_ - G_);

    }
    // (f)
    ofs.open( filename("-px1").c_str());
    ofs << "#x^n\tq(x)\t\tp(x)" << std::endl;
    for (size_t i=0; i < N_; ++i){
      ofs << i                                                 << "\t"
	  << input_pattern_distribution_[i]                    << "\t"
	  << boltzmann_distribution(W_, (*pall_pattern_)[i])   << "\n";
    }
    ofs.close();

    ofs.open(filename("-W").c_str());
    printLayer(ofs, W_);
    ofs.close();
  }

  void start()
  {
    std::ofstream ofs;
    learning_rule();
    ofs.open( filename("-W").c_str());
    printLayer(ofs, W_);
    ofs.close();
  }
};

int main(int argc, char** argv)
{
  const size_t degree = 3;
  const size_t n_allpattern = 0x01 << degree;
  const TimeOfRepeat T( 1000000 );
  const KstepGibbsSampling K( 1 );
  const DegreeOfVisibleVector D( degree );
  const NumberOfAllPattern N( n_allpattern );
  std::ofstream ofs;
  Probability input_pattern_distribution( n_allpattern, 1.0/n_allpattern );
  Probability transition_cell_distribution( degree, 1.0/degree );
  Threshold h( degree, 0.0 );
  std::vector<Pattern> all_pattern( n_allpattern, Pattern( degree, 0 ));

  ofs.open("dir-dat/all_pattern.dat");
  for(size_t i=0; i < n_allpattern; ++i){
    Pattern& x = all_pattern[i];
    dtob<Pattern::iterator>(i, x.begin(), x.end()-1);
    ofs << "i=" << i                                              << "\t"
	<< "x=" << all_pattern[i]                                 << "\t"
	<< "d=" << btod<Pattern::iterator>( x.begin(), x.end()-1) << "\n";
  }
  ofs.close();
  
  Kadai1_simulation sim1(&all_pattern, T, K, D,
			 input_pattern_distribution  ,
			 transition_cell_distribution,
			 h,
			 "dir-dat/kadai1h");
  sim1.start();

  Kadai23_simulation sim23(&all_pattern, T, K, D,
			   input_pattern_distribution  ,
			   transition_cell_distribution,
			   h,
			   "dir-dat/kadai23h");
  sim23.start();

  double qtbl4[n_allpattern] = {0.10, 0.10, 0.05, 0.05, 0.10, 0.10, 0.40, 0.10};
  std::copy(qtbl4, qtbl4 + n_allpattern, input_pattern_distribution.begin());
  //      Threshold h4(3); h4[0]= 0.0; h4[1]= 0.0; h4[2]= 0.0;
  Threshold h4(3); h4[0]= 0.7; h4[1]= 0.6; h4[2]= 0.3;// <- success.
  //  Threshold h4(3);{ h4[0]= -0.7; h4[1]= -0.6; h4[2]= -0.3;}<- wrong?
  Kadai4_simulation sim4(&all_pattern, T, K, D, 
			 input_pattern_distribution  ,
			 transition_cell_distribution,
			 h4,
			 "dir-dat/kadai4h");
  sim4.start();
  
  //int x_constrain[degree] = { 1, 0, 0 };
  double transition_cell[degree] = { 0.0, 0.5, 0.5 };
  double qtbl5[n_allpattern] = {0.0, 0.0, 0.0, 0.0, 0.142, 0.142, 0.571, 0.142};
  std::copy( qtbl5,
	     qtbl5 + n_allpattern,
	     input_pattern_distribution.begin());
  std::copy( transition_cell,
	     transition_cell + degree,
	     transition_cell_distribution.begin());
  //{ h4[0]= 0.0; h4[1]= 0.0; h4[2]= 0.0;}
  Kadai5_simulation sim5(&all_pattern, T, K, D,
			 input_pattern_distribution  ,
			 transition_cell_distribution,
			 sim4.getW(), h4, "dir-dat/kadai5h");
  sim5.start();
  //constrain, transition_cell, x_constrain,
  return 0;
}


  //                   1.0
  // Pr{x_i} = ------------------
  //             1.0 + exp(-u)

  // 
  // E(x) = - \sum_{i<j} w_{ij} x_{i} x_{j}
  // 

  //                   exp(-E(x))
  // p(x) = ---------------------------
  //         \sum_{i}{ exp(-E(x)) }

  //                                      1.0
  // p(x_n) = --------------------------------------------------------------
  //         exp(-E(x_0))    exp(-E(x_1))          exp(-E(x_2))     exp(-E(x_3))         
  //         ------------- + ------------- + ... + ------------- + ------------- 
  //         exp(-E(x_n))    exp(-E(x_n))          exp(-E(x_n))     exp(-E(x_n))  
  
  // double boltzmann_distribution(const Layer& W, const Pattern& x)
  //   {
  //     double ret = 0.0;
  //     const std::vector<Pattern>& all_pattern = *pall_pattern_;
  //     size_t number_of_allpattern = all_pattern.size();
  //     double en = energy(W,x);
  //     double ei;
  //     for (size_t i=0; i < number_of_allpattern; ++i){
  //       ei   = energy(W, all_pattern[i]);
  //       ret += exp(en - ei);
  //       //std::cout << "i=" << i << "ret=" << ret << "1./ret" << 1./ret << std::endl;
  //     }
  //     return 1./ret;
  //   }


    // Pattern     x_constrain(D_);
    //     Probability transition_cell(D_);
    //     for(size_t i=0; i < D_; ++i){
    //       x_constrain[i]     = constrain[i].first;
    //       transition_cell[i] = constrain[i].second;
    //     }
    //     set_select_cell( std::vector<Probability>(1, transition_cell) );
    // Probability input_pattern_distribution2(N_);
    //     double max = 100000;
    //     for (size_t i=0; i < max; ++i){
    //       bool redo;
    //       do{
    // 	redo = false;
    // 	v_ = (*pall_pattern_)[ random_select_pattern() ];
    // 	for (size_t j=0; j < D_; ++j){
    // 	  if ( 1 == static_cast<int>( x_constrain[j] ) &&
    // 	       0 == static_cast<int>( v_[j] )         )
    // 	    { redo = true; }
    // 	}
    //       } while(redo);
    //       input_pattern_distribution2[ btod<Pattern::iterator>
    // (v_.begin(), v_.end()-1) ]++;
    //     }
    //     for(size_t i=0; i < input_pattern_distribution2.size(); ++i){
    //       input_pattern_distribution2[i] /= max;
    //     }
    // double sum = accumulate(input_pattern_distribution2.begin(),
    // input_pattern_distribution2.end()  , 0.0);

    // for (size_t i=0; i < N_; ++i){
    //       cout << "q(" << (*pall_pattern_)[i] << "|x_1)="
    // 	   << input_pattern_distribution2[i] / sum << "\t\t";
    //       cout << "q(" << (*pall_pattern_)[i] << ")="
    // 	   << input_pattern_distribution[i] << endl;
    //     }
    // FILE *fp = fopen(filename("-qn").c_str(),"w");
    //     for (size_t i=0; i < input_pattern_distribution_.size(); ++i){
    //       fprintf(fp, "%d %lf %lf\n",
    // 	      i,
    // 	      input_pattern_distribution_[i],
    // 	      input_pattern_distribution2[i]);
    //     }
    //fclose(fp);
    // copy(input_pattern_distribution.begin(),
    // 	 input_pattern_distribution.end(),
    // 	 ostream_iterator<double>(cout, "\t"));
    //    assert(false);
    //    input_pattern_distribution_ = input_pattern_distribution2;
    //    set_select_pattern(std::vector<Probability>(input_pattern_distribution_));
    //    std::cout << __FUNCTION__ << "-" << __LINE__ << "v_=" << v_ << std::endl;
    //    std::cout << __FUNCTION__ << "-" << __LINE__ << x_constrain << std::endl;
    //    copy(transition_cell.begin(), transition_cell.end(),
    //	 std::ostream_iterator<double>(cout, "\t"));
