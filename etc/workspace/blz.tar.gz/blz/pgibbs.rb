#/usr/bin/ruby


str = "va_gibbs2"
weight = [0.0, 0.1, 0.2, 0.3]
init_onbit = 0
k_step = 10
sampling_time = 10000

input_file = weight.collect{|w|
  str + "_d#{k_step}_w" + ("%.1f"%[w]).gsub('.','') + '.dat'
}

dataset = []
input_file.each{|fname|
  File::open( fname ){|f|
    while line = f.gets
      if (!/^\#/)
        data = line.chomp.strip.split
        data = data.collect{|s| s.to_f}
        p data
        dataset.push( data )
      end
    end
  }
}

#dataset.transpose
IO.popen("gnuplot -persist", "w"){|io|
  io.puts "set grid"
  io.puts "set terminal postscript enhanced color eps"
  io.puts "set output 'va_gibbs2_onbit_prob.eps'"
  io.puts "set title '#{k_step} step gibbs, sample = #{sampling_time}'"
  io.puts "set key top left"
  io.puts "set xlabel 'number of onbit'"
  io.puts "set ylabel 'probability'"
  io.puts "set yrange [0:1]"
  title = (weight.collect{|w| "'-' with lines title 'Weight=#{w}'"}).join(",")
  io.puts "plot #{title}"
  dataset.each{|data|
    data.each{|d|
      io.puts d
    }
    io.puts "e"
  }
}
