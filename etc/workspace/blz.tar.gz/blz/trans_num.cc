#include <vector>
#include <iostream>
#include <iterator>
#include <algorithm>

#define N 5

using namespace std;

template<typename Iterator>
void dtob(int d, Iterator p0, Iterator pN)
{
  int n = pN - p0 + 1;
  while (n--){
    *pN-- = d & 0x01;
    d >>= 1;
  }
}

template<typename Iterator>
int btod(Iterator p0, Iterator pN)
{
  int n = 0;
  int MSB = 0x01 << (pN-p0);
  while (MSB){
    n += (*p0++)*MSB;
    MSB >>= 1;
  }
  return n;
}

// void dtob(int d, int *p0, int *pN)
// {
//   int n = pN - p0 + 1;
//   while (n--){
//     *pN-- = d & 0x01;
//     d >>= 1;
//   }
// }

// int btod(int *p0, int *pN)
// {
//   int n = 0;
//   int MSB = 0x01 << (pN-p0);
//   while (MSB){
//     n += (*p0++)*MSB;
//     MSB >>= 1;
//   }
//   return n;
//}

int main()
{
  int x[N] = {0, 0, 0, 0, 0};
  int y[N];

  vector<int> v(x, x+N);

  for (size_t i=0; i < 16; ++i){
    dtob<int*>(i, &x[2], &x[4]);
    dtob<vector<int>::iterator>(i, v.begin()+2, v.begin()+4);
    cout << "i = " << i << "|\t";
    //copy(x, x + N, ostream_iterator<int>(cout, "|\t"));
    //cout << btod<int*>(&x[1], &x[4]);
    copy(v.begin(), v.end(),
	 ostream_iterator<int>(cout, "|\t"));
    cout << btod<vector<int>::iterator >(v.begin()+2, v.begin()+4);
    //cout << btod<int*>(&x[1], &x[4]);

    cout << endl;
  }
  return 0;
}
