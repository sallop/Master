#include <cstdio>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>
//#include <boost/numeric/ublas/zero_matrix.hpp>
#include <boost/numeric/ublas/symmetric.hpp>
//#include <boost/numeric/ublas/diagonal_matrix.hpp>
#include <boost/numeric/ublas/banded.hpp>
#include <boost/numeric/ublas/io.hpp>

using namespace boost::numeric::ublas;

namespace ublas = boost::numeric::ublas;


template<typename T>
void set_tr0(matrix<T> &m)
{
  diagonal_adaptor<matrix<T> > tr(m);
  tr = zero_matrix<T>(tr.size1());
}

template<typename T>
matrix<T> add_tr0_matrix(const matrix<T>& m1, const matrix<T>& m2)
{
  matrix<T> ret(m1);
  //  diagonal_adaptor<matrix<T> > tr(ret);
  ret = m1 + m2;
  set_tr0<T>(ret);
  //  tr = zero_matrix<T>(m1.size1());
  return ret;
}

int main()
{
  matrix<double> m(3,3);
  vector<double> v(3);
  diagonal_adaptor<matrix<double> > tr(m);
  for (unsigned i=0; i < m.size1(); ++i){
    for (unsigned j=0; j < m.size2(); ++j){
      m(i,j) = 1;
    }
  }
  v[0] = 1; v[1] = 1; v[2] = 1;
  //  tr = zero_matrix<double>(3);
  std::cout << m << std::endl;
  m = add_tr0_matrix<double>(m, outer_prod(v,v));
  std::cout << m << std::endl;

  symmetric_matrix<double, lower> ml(3,3);
  for (unsigned i=0; i < ml.size1(); ++i)
    for (unsigned j=0; j <= i; ++j)
      ml (i,j) = 3*i + j;

  std::cout << ml << std::endl;

  symmetric_matrix<double, upper> mu(3,3);
  for (unsigned i=0; i < mu.size1(); ++i)
    for (unsigned j=i; j < mu.size2(); ++j)
      mu (i,j) = 3*i + j;

  std::cout << mu << std::endl;

  //  m = add_tr0_matrix(ml, mu);   <- error
  //  std::cout << m << std::endl;  <- error

  return 0;
}
