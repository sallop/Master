#include <iostream>
#include <cstdio>
#include <iostream>
#include <boost/numeric/ublas/io.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix_proxy.hpp>
#include <boost/numeric/ublas/symmetric.hpp>
#include <boost/numeric/ublas/matrix.hpp>

int main()
{
  using namespace std;
  using namespace boost::numeric::ublas;

  int i,j,k;
  matrix<int> W(4,4);
  symmetric_matrix<int> Ws(4,4);

  for (size_t i=0; i < Ws.size1(); ++i){
      for (size_t j=0; j < Ws.size2(); ++j){
	Ws(i,j) = i*4+j;//w[i][j];
      }
  }

  cout << Ws << endl;

  Ws(1,0)= 2;
  for (size_t i=0; i < Ws.size1(); ++i){
    for (size_t j=0; j < Ws.size2(); ++j){
      printf("%d\t", Ws(i,j));
    }
    printf("\n");
  }

  W = Ws;
  cout << W << endl;

  Ws = W;
  cout << Ws << endl;

  // for (j=0; j < 4; j++){
//     for (i=0; i < j; i++){
//       W
//       //printf("(i=%d,j=%d)=%d", i,j,W(i,j));
//     }
//     printf("\n");
//   }
  
  return 0;
}
