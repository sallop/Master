#!/usr/bin/ruby

str = "va_gibbs2"
weight = [0.0, 0.1, 0.2, 0.3]
init_onbit = 0
k_step = 10

send_commands = weight.collect{|w| "./#{str} #{init_onbit} #{w}"}
output_file = weight.collect{|w| str + "_d#{k_step}_w" + ("%.1f"%[w]).gsub('.','') + '.dat'}

cmdioset = []
for i in 0..weight.size()-1
  cmdioset.push( [send_commands[i], output_file[i]] )
end

#send_commands.size.times{
#  cmdioset.push [send_commands.shift, output_file.shift]
#}


#send_commands.each do |cmd|  
cmdioset.each do |cmd, ofile|  
  lines = []
  IO.popen(cmd) do |io|
    while io.gets()
      lines.push($_)
      #puts $_
    end
  end
  # Output
  #fo = File.open(ofile,'w')
  #fo.close()
  File.open(ofile,'w'){|dest|
    dest.write( lines )
  }
end
