#include "TrainDataFactory.hpp"

Pattern TrainDataFactory::create()
{
  PASS;
  return createPattern();
}

Pattern TrainDataFactory::create(int no)
{
  PASS;
  return createPattern(no);
}

void TrainDataFactory::registry()
{ 
  PASS;
  registerPattern();
}

void TrainDataFactory::registry(int* pattern, size_t size)
{
  PASS;
  registerPattern( pattern, size );
}

void TrainDataFactory::registry(Pattern pattern)
{
  PASS;
  registerPattern( pattern );
}

void TrainDataFactory::registry(std::vector<Pattern> patterns)
{
  for(int i=0; i < patterns.size(); i++)
    registerPattern( patterns[i] );
}

Pattern TrainDataFactory::createPattern()
{
  NOTIMPLIMENT;
  return Pattern(0);
}

Pattern TrainDataFactory::createPattern(int no)
{
  NOTIMPLIMENT;
  return Pattern(0);
}
void TrainDataFactory::registerPattern()
{ 
  NOTIMPLIMENT;
}
void TrainDataFactory::registerPattern(int no)
{
  NOTIMPLIMENT;
}
void TrainDataFactory::registerPattern(Pattern pattern)
{
  NOTIMPLIMENT;
}
void TrainDataFactory::registerPattern(int* pattern, size_t size)
{
  NOTIMPLIMENT;
}

ArbitararyTrainData::ArbitararyTrainData(int size) : size_(size)
{
  it_ = data_.begin(); 
}

Pattern ArbitararyTrainData::createPattern(){
  PASS;
  return *it_++;
}

Pattern ArbitararyTrainData::createPattern(int no)
{
  PASS; 
  return data_[no];
}

void ArbitararyTrainData::registerPattern(int *pattern, size_t size)
{
  Pattern p(size);
  std::copy( pattern, pattern+size, p.begin() );
  data_.push_back(p);
}

void ArbitararyTrainData::registerPattern(Pattern pattern)
{
  data_.push_back(pattern);
}

RandomTrainData::RandomTrainData(int size)
  : size_(size), flip_probablity(size)
{
  it_ = data_.begin();
}

Pattern RandomTrainData::createPattern()
{
  return *it_++;
}

Pattern RandomTrainData::createPattern(int no)
{
  if (no < 0 && no >= data_.size()){
    std::cout << __FUNCTION__ << " " << __LINE__ << std::endl;
    return Pattern();
  }
  return data_[no];
}

void RandomTrainData::registerPattern()
{
  int* pattern = new int[size_];
  registerPattern( pattern, size_ );
  delete[] pattern;
}

void RandomTrainData::registerPattern(int *pattern, size_t size)
{
  if (size != size_){
    std::cerr << __FUNCTION__ << "-" << __LINE__ 
	      << "size =" << size
	      << "size_=" << size_
	      << std::endl;
    assert(false);
  }
  Pattern p(size);
  std::copy( pattern, pattern + size, p.begin());
  registerPattern( p );
}

void RandomTrainData::registerPattern(Pattern pattern)
{
  for(int i=0; i < size_; i++){
    if ( drand48() < flip_probablity[i] ){ 
      pattern[i] = static_cast<int>( pattern[i] )^0x01;
    }
  }
  //pattern[i] = (pattern[i] == 0) ? 1 : 0;
  data_.push_back(pattern);
}

void RandomTrainData::setProb(int n, double prob)
{
  if (n < 0 || n > size_){
    std::cerr << __FUNCTION__ << "-" << __LINE__ 
	      << " Error occured "
	      << "size_ = " << size_
	      << "n     = " << n
	      << std::endl;
    assert(false);
  }
  flip_probablity[n] = prob;
}

void RandomTrainData::printProb()
{
  for(int i=0; i < flip_probablity.size(); i++){
    std::cout << "P(" << i << ")="
	      << flip_probablity[i] << std::endl;
  }
}
