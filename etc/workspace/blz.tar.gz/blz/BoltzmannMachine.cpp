#include <iostream>
#include <cmath>
#include <cmath>
#include <cfloat>
#include <cstdlib>
#include <cassert>
#include <time.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <vector>
#include <functional>
#include <numeric>
#include <execinfo.h>
#include <exception>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/variate_generator.hpp>
#include "BoltzmannMachine.hpp"
#include "RollWeightedDie.hpp"
#include "Pattern.hpp"

#ifdef DEBUG
# define PASS std::cout << __FUNCTION__ << "-" << __LINE__ << std::endl
# define DOUT(str) std::cout << (str) << std::endl;
#else
# define PASS
# define DOUT(str)
#endif

typedef double UnitType;
typedef boost::numeric::ublas::vector<UnitType> Pattern;
typedef boost::numeric::ublas::matrix<UnitType> Layer  ;

static void pVector(const Pattern &v)
{
  for (size_t i=0; i < v.size(); ++i){
    printf("%.3lf\t", v[i]);
  }
  printf("\n");
}

BoltzmannMachine::BoltzmannMachine()
{
  pRandom_select_cell_ = NULL;
  PASS;
}

BoltzmannMachine::BoltzmannMachine(std::vector<Pattern>* pall_pattern,
				   const TimeOfRepeat& T,
				   const KstepGibbsSampling& K)
  : pall_pattern_(pall_pattern), N_(pall_pattern->size()), T_(T.data_), K_(K.data_)
{
  PASS;
  pRandom_select_cell_ = NULL;
}

void BoltzmannMachine::learn()
{
  this->learning_rule();
}

//Pattern BoltzmannMachine::gibbs_sampling(const Pattern& x_t)
Pattern BoltzmannMachine::gibbs_sampling(const Layer &W, Pattern x_t1)
{  //Pattern x_t1( x_t );
  int dimmension = x_t1.size();
  std::vector<int> generated_random_number(K_);
  for (size_t k=0; k < K_; k++){
    generated_random_number[k] = random_select_cell(); 
  }
  
  for (size_t k=0; k < K_; k++){
    // update cells
    double u_i = 0.0;
    int i = generated_random_number[k];
    for (int j=0; j < dimmension; j++){
      u_i += W(i,j)*x_t1(j);
    }
    x_t1[i] = (sigmoid(u_i) > drand48()) ? ONBIT : OFFBIT;
  }
  return x_t1;
}

double BoltzmannMachine::partition_function(const Layer& W, const std::vector<Pattern>& patterns)
{
  int number_of_allpattern = patterns.size();
  double z = 0.0;
  for (int n = 0; n < number_of_allpattern; n++){
    const Pattern& x = patterns[n];
    z += exp( -energy(W,x) );
  }
  return z;
}

double BoltzmannMachine::KL_divergence(const Probability& P, const Probability& Q)
{ 
  double d = 0.0;
  assert(P.size() == Q.size());
  for (size_t i = 0; i < P.size(); i++){
    assert(P[i] >= 0);
    assert(Q[i] >= 0);
    d += P[i]*log(P[i]/Q[i]);
    //d += P[i]*(log(P[i]) - log(Q[i]));
    //d += P[i]*log(P[i]) - P[i]*log(Q[i]);
  }
  return d; 
}

// {// \frac{ exp(-E(x) }{ \sum_{x} energy(x) }
double BoltzmannMachine::boltzmann_distribution(const Layer& W, const Pattern& x)
{
  double ene   = -energy(W,x);
  double numer = exp(ene);//  double numer = exp(-energy(W,x));
  double denom = partition_function(W,(*pall_pattern_));
  return numer/denom;
}
// {
//   const std::vector<Pattern> all_pattern = *pall_pattern_;
//   size_t number_of_allpattern = all_pattern.size();
//   double ex, en, ret = 0.0;
//   ex = energy(W, x);
//   for (size_t n=0; n < number_of_allpattern; ++n){
//     en = energy( W, all_pattern[n]);
//     ret = exp(ex - en);
//   }
//   return 1.0/ret;
// }


// to late
double BoltzmannMachine::energy(const Layer& W, const Pattern& x)
{ //-*-original-*-
  double sum = 0.0;
  for (size_t j=0; j < W.size2(); j++){
    for (size_t i=0; i < j; i++){
      sum += W(i,j)*x(i)*x(j);
    }
  }
  return -sum;
}

double BoltzmannMachine::energy2(const Layer& W, const Pattern& x)
{ 
  double sum = 0.0;
  for (size_t i=0; i < W.size1(); i++){
    for (size_t j=0; j < W.size2(); j++){
      sum += W(i,j)*x(i)*x(j);
    }
  }
  return -sum/2.0;
}

BoltzmannMachine1L::BoltzmannMachine1L(std::vector<Pattern>* pall_pattern,
				       const TimeOfRepeat          &T,
				       const KstepGibbsSampling    &K,
				       const DegreeOfVisibleVector &D,
				       const Probability &input_pattern_distribution,
				       const Probability &transition_cell_distribution)
 : BoltzmannMachine(pall_pattern, T, K),
   W_(D.data_,D.data_),
   F_(D.data_,D.data_),
   G_(D.data_,D.data_),
   D_(D.data_),
   input_pattern_distribution_(input_pattern_distribution),
   transition_cell_distribution_(transition_cell_distribution)
{
  PASS;
  assert (input_pattern_distribution.size() == input_pattern_distribution_.size());
  pRandom_select_pattern_ = new RollWeightedDie( input_pattern_distribution_   );
  pRandom_select_cell_    = new RollWeightedDie( transition_cell_distribution_ );
  for (size_t i=0; i < W_.size1(); i++){
    for (size_t j=0; j < W_.size2(); j++){
      W_(i,j) = 0.0;
    }
    W_(i,i) = 0.0;
  }
}

double BoltzmannMachine1L::calc_KL_divergence()
{
  const size_t number_of_allpattern = pall_pattern_->size();
  Probability P( number_of_allpattern );
  const Probability& Q = input_pattern_distribution_;
  for (size_t i=0; i < number_of_allpattern; i++){
    P[i] = boltzmann_distribution( W_, (*pall_pattern_)[i] );
  }
  return KL_divergence(P, Q);
}

void BoltzmannMachine1L::learning_rule()
{
  PASS;
  std::cout << "BoltzmannMachine1L::learning_rule() called!!" << std::endl;
}

void BoltzmannMachine1L::sub_set_select_cell(const std::vector<Probability>& probabilities)
{
  const Probability &probability = probabilities[0];
  // one layer use a probabilities[n]
  // this value set a select cell probabilities
  if (NULL != pRandom_select_cell_){
    delete pRandom_select_cell_;
  }
  assert(probability.size() == D_);
  std::copy(probability.begin(),
	    probability.end()  ,
	    transition_cell_distribution_.begin());
  pRandom_select_cell_ = new RollWeightedDie ( transition_cell_distribution_ );
}

void BoltzmannMachine1L::sub_set_select_pattern(const std::vector<Probability>& probabilities)
{
  const Probability &probability = probabilities[0];
  // one layer use a probabilities[n]
  // this value set a select cell probabilities
  assert(probability.size() != D_);
  if (NULL != pRandom_select_pattern_){
    delete pRandom_select_pattern_;
  }
  std::copy(probability.begin(),
	    probability.end()  ,
	    input_pattern_distribution_.begin());
  pRandom_select_pattern_ = new RollWeightedDie( input_pattern_distribution_ );
}

BoltzmannMachine1L_threshold::BoltzmannMachine1L_threshold(std::vector<Pattern>* pall_pattern,
							   const TimeOfRepeat          &T,
							   const KstepGibbsSampling    &K,
							   const DegreeOfVisibleVector &D,
							   const Probability &input_pattern_distribution,
							   const Probability &transition_cell_distribution,
							   const Threshold   &h)
  : BoltzmannMachine1L(pall_pattern, T, K, D,
		       input_pattern_distribution,
		       transition_cell_distribution), h_(h)
{
  PASS;
}

void BoltzmannMachine2L::learning_rule()
{
  PASS;
}

BoltzmannMachine2L::BoltzmannMachine2L()
{
  PASS;
}

void BoltzmannMachine2L::sub_set_select_cell(const std::vector<Probability>& probabilities)
{
  assert (false);
}

void BoltzmannMachine2L::sub_set_select_pattern(const std::vector<Probability>& probabilities)
{
  assert (false);
}


BoltzmannMachine3L::BoltzmannMachine3L()
{
  PASS;
}

void BoltzmannMachine3L::sub_set_select_cell(const std::vector<Probability>& probabilities)
{
  assert (false);
}

void BoltzmannMachine3L::sub_set_select_pattern(const std::vector<Probability>& probabilities)
{
  assert (false);
}

void BoltzmannMachine3L::learning_rule()
{
  PASS;
}
