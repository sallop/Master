// boltzmann machine 2011/5/19
// boltzmann machine 2011/5/25
#include <cmath>
#include <cfloat>
#include <cstdlib>
#include <cassert>
#include <time.h>
#include <iostream>
#include <iomanip>
#include <fstream>
#include <algorithm>
#include <vector>
#include <functional>
#include <numeric>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/vector.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/random/mersenne_twister.hpp>
#include <boost/random/uniform_real.hpp>
#include <boost/random/variate_generator.hpp>

using namespace std;
using namespace boost::numeric::ublas;

typedef boost::numeric::ublas::vector<int>		iVector;
typedef boost::numeric::ublas::vector<double>		dVector;
typedef boost::numeric::ublas::matrix<double>		dMatrix;
typedef boost::numeric::ublas::zero_matrix<double>	dZeroMatrix;

#define DENERGY 0
#define DEBUG
boost::mt19937 gen;


int brand(){ return drand48() > 0.5 ? 1 : 0; }
void dtob(int n, iVector& v)
{
  for(int i=0; i < v.size(); i++){
    v[i] = (n >> i) & 0x01;
  }    //{ v[i] = (n >> i)&0x01 ? 1 : 0; }
}

int btod(const iVector& v, int& n)
{
  n = 0;
  for(int i=0; i < v.size(); i++){
    n += static_cast<int>(v[i]) << i;
    //if(v[i] == 1){ n += 0x01 << i; }
  }
  return n;
}

int btod(const iVector& v)
{
  int n = 0;
  int size = v.size();
  for(int i=0; i < size; i++){
    n += static_cast<int>(v[i]) << i;
  }//    if(v[i] == 1){ n += 0x01 << i; }
  return n;
}


class RollWeightedDie
{
  int N_;  
  std::vector<double>& prob_;
public:
  RollWeightedDie(std::vector<double>& prob)
    : N_(prob.size()), prob_(prob)
  {}

  int roll()
  {
    std::vector<double> cumulative; // 累積する
    std::partial_sum(prob_.begin(), prob_.end(),
		     std::back_inserter(cumulative));
    boost::uniform_real<> dist(0, cumulative.back());
    boost::variate_generator<boost::mt19937&,boost::uniform_real<> >
      die(gen, dist);
    return
      (std::lower_bound(cumulative.begin(), 
			cumulative.end()  ,
			die()) - cumulative.begin());
  }
};

class BoltzmannMachine
{
public:
  dMatrix W_;			// model parameter
  dMatrix F_;			// data dependent expection
  dMatrix G_;			// model dependent expection
  std::vector<iVector> xs_;	// all state pattern
  int D_;			// visible vector degree
  int T_;			// repeat time
  int K_;			// K-step gibbs sampling
  int N_;			// number of all pattern
  double c_;			// normalization constant
  std::vector<double> Pr_q_;

  BoltzmannMachine(int d, int t, int k,
		   int n, std::vector<iVector> train_data)
    : W_(d,d), F_(d,d), G_(d,d),
      D_(d),
      T_(t),
      K_(k),
      N_(n),
      Pr_q_(n)
  {
    for(int j=0; j < D_; j++){
      for(int i=0; i < j; i++){
	W_(i,j) = W_(j,i) = drand48();
      }
      W_(j,j) = 0.0;
    }
    
    std::cout << __FUNCTION__ << std::endl;
    xs_ = train_data;
    for_each(xs_.begin(), xs_.end(), 
	     std::cout << boost::lambda::_1 << '\n');
    // assert(false);
    // for(int n=0; n < N_; n++){
    //  dtob(n, xs_[n]);
    // }
    c_ = 1./partition_function<double>(W_);
  }

  double KL_divergence()
  {
    double d = 0.0;
    c_ = 1./partition_function<double>(W_);

    for(int n=0; n < N_; n++){
      const iVector& x = xs_[n];
      double p = eq3<double>(x);
      double q = Pr_q_[n];
      assert(p >= 0.0 && p <= 1.0);
      assert(q >= 0.0 && q <= 1.0);
      d += p*log(p/q);
    }
    return d;
  }

  void print_symmetric_element(const dMatrix& Theta) const
  {
    for(int i=0; i < Theta.size1(); i++){
      for(int j=0; j < i; j++){
	std::cout << "(i,j)=" << Theta(i,j) << "\n";
	std::cout << "(j,i)=" << Theta(j,i) << "\n";
      }
      std::cout << "(i,i)=" << Theta(i,i) << "\n";
      std::cout <<   "----------------------------" << std::endl;
    }
  }

  template<class T>
  void print_vector(std::ostream& os, T& v, int n)
  {
    for(int i=0; i < n; i++){ os << v[i] << "   "; }
    os << std::endl;
  }

  template<class T>
  void print_Matrix(std::ostream& os, T& m)
  {
    for(int i=0; i < m.size1(); i++){
      for(int j=0; j < m.size2(); j++){
	os << std::setw(16) << std::left << m(i,j) << "\t";
      }
      os << std::endl;
    }
  }
  
  template<class T>
  void print_Matrix_column(std::ostream& os, T& m)
  {
    for(int i=0; i < m.size1(); i++){
      for(int j=0; j < m.size2(); j++)
	{os << std::setw(16) << std::left << m(i,j) << "\t";}
    }
    os << std::endl;
  }


  template<typename T>T
  partition_function(const dMatrix& Theta_) const
  {
    int i,j,n;
    T z = 0.0;
    for(n=0; n < N_; n++){
      const iVector& x = xs_[n];
      z += exp(-eq4<T>(x));
    }
    assert(z > 0.0);
    return z;
  }

  double sigma(double x) const
  {
    double y = 1./(1. + exp(-x));
    assert(y > 0);
    return y;
  }
  
  // probability p(x)
  template<typename T>T
  eq3(const iVector& x) const
  {
    T c = 1./partition_function<T>(W_);
    T y = c*exp(-eq4<T>(x));
    assert(c > 0 && c <= DBL_MAX);
    //assert(y >= 0.0 && y <= 1.0);
    if(!(y >= 0.0 && y <= 1.0)){
      std::cout << "error occured" << std::endl;
      std::cout << "DBL_MAX=" << DBL_MAX  << std::endl;
      std::cout << "DBL_MIN=" << DBL_MIN  << std::endl;
      std::cout << "y = " << y  << std::endl;
      std::cout << "c = " << c  << std::endl;
      std::cout << "W_= " << W_ << std::endl;
      assert(y >= 0.0 && y <= 1.0);
    }
    return y;
  }

  // double eq3(const iVector& x) const
//   {
//     double c = 1./partition_function(W_);
//     double y = c*exp(-eq4(x));
//     assert(c > 0    && c <= DBL_MAX);
//     //assert(y >= 0.0 && y <= 1.0);
//     if(!(y >= 0.0 && y <= 1.0)){
//       std::cout << "error occured" << std::endl;
//       std::cout << "DBL_MAX=" << DBL_MAX  << std::endl;
//       std::cout << "DBL_MIN=" << DBL_MIN  << std::endl;
//       std::cout << "y = " << y  << std::endl;
//       std::cout << "c = " << c  << std::endl;
//       std::cout << "W_= " << W_ << std::endl;
//       assert(y >= 0.0 && y <= 1.0);
//     }
//     return y;
//   }
  
  // Energy function

//   template<typename T>T
//   eq4(const iVector& x) const
//   {
//     int i, j;
//     T energy = 0.0;

//     for(j=0; j < D_; j++){
//       energy += W_(0,j)*x(j);
//       for(i=1; i < j; i++){
//   	energy += W_(i,j)*x(i)*x(j);
//       }
//     }
// #if DENERGY == 1
//     T max_energy = 0.0;
//     T min_energy = 0.0;
//     for(int j=0; j < D_; j++){
//       for(int i=0; i < j; i++){
// 	if (W_(i,j) >= 0){ max_energy += W_(i,j); }
// 	else { min_energy += W_(i,j); }
//       }
//     }
//     std::cout << "max_energy =" << max_energy << std::endl;
//     std::cout << "min_energy =" << min_energy << std::endl;
// #endif
//     return -energy;
//  }
  
  template<typename T>T
  eq4(const iVector& x) const
  {
    int i, j;
    T energy = 0.0;

    for(j=0; j < D_; j++){
      for(i=0; i < j; i++){
  	energy += W_(i,j)*x(i)*x(j);
      }
    }
#if DENERGY == 1
    T max_energy = 0.0;
    T min_energy = 0.0;
    for(int j=0; j < D_; j++){
      for(int i=0; i < j; i++){
	if (W_(i,j) >= 0){ max_energy += W_(i,j); }
	else { min_energy += W_(i,j); }
      }
    }
    std::cout << "max_energy =" << max_energy << std::endl;
    std::cout << "min_energy =" << min_energy << std::endl;
#endif
    return -energy;
  }


  // inline double eq4(const iVector& x) const
//   {
//     int i, j;
//     double energy = 0.0;

//     for(j=0; j < D_; j++){
//       for(i=0; i < j; i++){
//   	energy += W_(i,j)*x(i)*x(j);
//       }
//     }
// #if DENERGY == 1
//     double max_energy = 0.0;
//     double min_energy = 0.0;
//     for(int j=0; j < D_; j++){
//       for(int i=0; i < j; i++){
// 	if (W_(i,j) >= 0){ max_energy += W_(i,j); }
// 	else { min_energy += W_(i,j); }
//       }
//     }
//     std::cout << "max_energy =" << max_energy << std::endl;
//     std::cout << "min_energy =" << min_energy << std::endl;
// #endif
//     return -energy;
//   }

  inline void update_cell(iVector& x, const int& i)
  {// may be paper is wrong
    double u_i = 0.;
    assert(i >= 0);

    for(int j=0; j < D_; j++){ u_i += W_(i,j)*x(j); }
    //    x[i] = (drand48() < sigma(u_i)) ? 1 : 0;
    if(drand48() < sigma(u_i)){
      x[i] = 1;
	} else {
      x[i] = 0;
    }
  }

  void procedure1(int t)
  {
    std::vector<long long int> count(N_);
    std::vector<double> Pr(D_);
    iVector x(D_);
    iVector x_sr(D_-1);		// shift to the right 
    T_ = t;
    W_ = dZeroMatrix(D_,D_);

    std::fill(count.begin() , count.end(),         0);
    std::fill(Pr.begin() + 1, Pr.end()   , 1./(D_-1));
    std::fill(x.begin()     , x.end()    ,         0);

    Pr[0] = 0;
    x[0]  = 1;

    std::cout << __LINE__ << " " << W_ << std::endl;

    RollWeightedDie rwd(Pr);
    for(int i=0; i < T_; i++){
      int select_cell = rwd.roll();
      //std::cout << __FUNCTION__ << "_" << __LINE__ << std::endl;
      update_cell(x, select_cell);
      //      std::cout << __FUNCTION__ << "_" << __LINE__ << std::endl;
      copy(x.begin()+1, x.end(), x_sr.begin());
      //      std::cout << __FUNCTION__ << "_" << __LINE__ << std::endl;
      count[btod(x_sr)]++;
      //      std::cout << __FUNCTION__ << "_" << __LINE__ << std::endl;
      //print_Matrix<dMatrix>(cout, W_);
      //     print_vector<iVector>(cout, x, D_);
    }
    
    std::vector<double> p_x(N_);
    for(int i=0; i < p_x.size(); i++){
      p_x[i] = 
	static_cast<double>(count[i])/
	static_cast<double>(      T_);
    }
    std::ofstream ofs1("procedure1c.dat");
    std::ofstream ofs2("procedure1p.dat");
    std::cout << __FUNCTION__ << __LINE__ << std::endl;
    print_vector<std::vector<long long int> >
      (std::cout, count, count.size());
    print_vector<std::vector<double> >
      (std::cout, p_x, p_x.size());
    for(int i=0; i < N_; i++){
      ofs1 << count[i] << std::endl;
      ofs2 <<   p_x[i] << std::endl;
    }
  }

  // void procedure2(int t)
//   {
//     T_ = t;
//     std::vector<long long int> count(N_+1);
//     std::vector<double> experimental(N_+1);
//     std::vector<double>  theoretical(N_+1);
//     iVector x(D_), x_sr(D_-1);
//     std::vector<double> Pr_cell(D_);
//     // std::fill(Pr_cell.begin()+1,
// // 	      Pr_cell.end()    ,
// // 	      1./static_cast<double>(D_-1));
//     std::fill(Pr_cell.begin(),
//      	      Pr_cell.end()  ,
// 	      static_cast<double>(1./D_));
//     x[0] = 1;
//     Pr_cell[0] = 0;
//     RollWeightedDie rwd(Pr_cell);
//     iVector& x3 = xs_[3];
//     iVector& x6 = xs_[6];

//     std::fill(count.begin(), count.end(), 0);
//     std::fill(x.begin()    , x.end()    , 0);
//     std::fill(x_sr.begin() , x_sr.end() , 0);

//     W_ = dZeroMatrix(D_,D_);
//     for(int i=0; i < D_; i++){
//       for(int j=0; j < D_; j++){
// 	W_(i,j) += (2.*x3[i]-1.)*(2.*x3[j]-1.);
// 	W_(i,j) += (2.*x6[i]-1.)*(2.*x6[j]-1.);
//       }
//       W_(i,0) = W_(0,i) = drand48();
//       W_(i,i) = 0.0;
//     }

//     //std::cout << W_ << std::endl;

//     print_Matrix(std::cout, W_);
//     //assert(false);



//     for(int i=0; i < T_; i++){
//       x[0] = 1;
//       int select_cell = rwd.roll();
//       //      int select_cell = 1 + random()%3;
//       int d;

//       update_cell(x, select_cell);

//       std::cout << "i=" << i << "x=" << x << std::endl;
//       std::copy(x.begin()+1, x.end(), x_sr.begin());

//       //      d = btod(x_sr);
//       //print_vector<iVector>(std::cout, x, x.size());
//       //      print_vector<iVector>(std::cout, x_sr, x_sr.size());
//       //      count[d]++;
//       count[btod(x_sr)]++;
//     }
    
//     print_vector(std::cout, count, count.size());
//     //    assert(false);

//     for(int n=0; n < N_; n++){
//       theoretical[n]  = eq3<double>(xs_[n]);
//       experimental[n] = 
// 	static_cast<double>(count[n])/
// 	static_cast<double>(T_);
//       theoretical[ N_] += theoretical[n];
//       experimental[N_] += experimental[n];
//     }

//     std::stringstream sst;
//     std::stringstream sse;
//     std::stringstream ssw;
//     sst << "procedure2t" << t << ".dat";
//     sse << "procedure2e" << t << ".dat";
//     ssw << "procedure2w"  << t << ".dat";

//     std::ofstream ofst(sst.str().c_str());
//     std::ofstream ofse(sse.str().c_str());
//     std::ofstream ofsw(ssw.str().c_str());

//     print_vector<std::vector<long long int> >
//       (std::cout, count, count.size());
//     print_vector<std::vector<double> >
//       (std::cout, theoretical, theoretical.size());
//     print_Matrix<dMatrix>(std::cout, W_);
//     std::cout << W_ << std::endl;

//     print_Matrix<dMatrix>(ofsw, W_);
//     for(int i=0; i < N_+1; i++){
//       ofst <<  theoretical[i] << std::endl;
//       ofse << experimental[i] << std::endl;
//       //ofse << count[i] << std::endl;
//     }

    

//     std::cout << std::endl;

//     ofst.close();
//     ofse.close();
//     ofsw.close();
//   }


  void procedure2(int t)
  {
    T_ = t;
    std::vector<long long int> count(N_+1);
    std::vector<double> experimental(N_+1);
    std::vector<double>  theoretical(N_+1);
    iVector x   (D_  );
    iVector x_sr(D_-1);
    std::vector<double> Pr_cell(D_);
    Pr_cell[0] = 0;
    std::fill(Pr_cell.begin()+1,
	      Pr_cell.end()    ,
	      1./static_cast<double>(D_-1));


    RollWeightedDie rwd(Pr_cell);
    iVector& x3 = xs_[3];// x3[0] = 0;
    iVector& x6 = xs_[6];// x6[0] = 0;

    std::fill(count.begin(), count.end(), 0);
    std::fill(x.begin()    , x.end()    , 0);
    std::fill(x_sr.begin() , x_sr.end() , 0);
    x[0] = 0;


    W_ = dZeroMatrix(D_,D_);
    for(int i=0; i < D_; i++){
      for(int j=0; j < D_; j++){
	W_(i,j) += (2.*x3[i]-1.)*(2.*x3[j]-1.);
	W_(i,j) += (2.*x6[i]-1.)*(2.*x6[j]-1.);
      }
      //W_(i,0) = W_(0,i) = drand48();
      W_(i,i) = 0.0;
    }

    std::cout << W_ << std::endl;
    //assert(false);

    for(int i=0; i < T_; i++){
      //      x[0] = 1;
      int select_cell = rwd.roll();
      assert(select_cell >= 1);
      //      assert(x[0] ==  1);
      
      update_cell(x, select_cell);
      std::copy(x.begin()+1, x.end(), x_sr.begin());
      //print_vector<iVector>(std::cout, x, x.size());
      //      print_vector<iVector>(std::cout, x_sr, x_sr.size());
      count[btod(x_sr)]++;
    }
    
    print_vector(std::cout, count, count.size());
    //    assert(false);

    for(int n=0; n < N_; n++){
      xs_[n][0] = 0;
      theoretical[n] = eq3<double>(xs_[n]);
      experimental[n] = 
	static_cast<double>(count[n])/
	static_cast<double>(      T_);
      theoretical[ N_] += theoretical[n];
      experimental[N_] += experimental[n];
    }

    std::stringstream sst;
    std::stringstream sse;
    std::stringstream ssw;
    sst << "procedure2t" << t << ".dat";
    sse << "procedure2e" << t << ".dat";
    ssw << "procedure2w" << t << ".dat";

    std::ofstream ofst(sst.str().c_str());
    std::ofstream ofse(sse.str().c_str());
    std::ofstream ofsw(ssw.str().c_str());

    print_vector<std::vector<long long int> >
      (std::cout, count, count.size());
    print_vector<std::vector<double> >
      (std::cout, theoretical, theoretical.size());
    print_Matrix<dMatrix>(std::cout, W_);
    std::cout << W_ << std::endl;

    print_Matrix<dMatrix>(ofsw, W_);
    for(int i=0; i < N_+1; i++){
      ofst <<  theoretical[i] << std::endl;
      ofse << experimental[i] << std::endl;
      //ofse << count[i] << std::endl;
    }
    std::cout << std::endl;
    ofst.close();
    ofse.close();
    ofsw.close();
  }

  void procedure3(int t)
  {
    T_ = t;
    std::stringstream sst("procedure3");
    std::stringstream sse("procedure3");
    std::stringstream ssw("procedure3");
    sst << t << ".dat";
    sse << t << ".dat";
    ssw << t << ".dat";
    std::ofstream ofst(sst.str().c_str());
    std::ofstream ofse(sse.str().c_str());
    std::ofstream ofsw(ssw.str().c_str());

    iVector x(D_), x_sr(D_-1);
    std::vector<double> Pr_cell(D_);
    iVector& x3 = xs_[3];
    iVector& x6 = xs_[6];
    std::fill(Pr_cell.begin()+1, Pr_cell.end(), 1./(D_-1));
    
    // W_ = dZeroMatrix(D_,D_);
//     for(int i=0; i < D_; i++){
//       for(int j=0; j < D_; j++){
// 	W_(i,j) += (2.*x3[i]-1.)*(2.*x3[j]-1.);
// 	W_(i,j) += (2.*x6[i]-1.)*(2.*x6[j]-1.);
//       }
//       W_(i,i) = 0.0;
//     }

//     for(int i=0; i < T_; i++){
//       int select_cell = rwd.roll();
//       update_cell(x, select_cell);
//       std::copy(x.begin()+1, x.end(), x_sr.begin());
//       count[btod(x_sr)];
//     }

//     for(int n=0; n < N_; n++){
//       theoretical[n]  = eq3<double>(xs_[n]);
//       experimental[n] = ;
//     }

    ofst.close();
    ofse.close();
    ofsw.close();
  }

  
  void procedure4(double q_table[], int n_sample = 1000)
  {
    std::vector<long long int> count(N_+1);
    std::vector<double> Pr_cell(D_);
    iVector x(D_);
    iVector x_sr(D_-1);

    //dMatrix tF(D_,D_); tF = dZeroMatrix(D_,D_);

    std::fill(x.begin()        , x.end()      , 0            );
    std::fill(Pr_cell.begin()+1, Pr_cell.end(), 1./(D_-1)    );
    std::copy(q_table          , q_table + N_ , Pr_q_.begin());

    W_ = dZeroMatrix(D_,D_);
    F_ = dZeroMatrix(D_,D_);    
    G_ = dZeroMatrix(D_,D_);

    RollWeightedDie cell_select ( Pr_cell );
    RollWeightedDie state_select( Pr_q_   );

    std::ofstream ofs1("procedure4w.dat");
    std::ofstream ofs2("procedure4KL.dat");
    std::ofstream ofs3("procedure4P.dat");
    std::ofstream ofs4("procedure4f.dat");
    std::ofstream ofs5("procedure4g.dat");    
    std::ofstream ofs6("procedure4count.dat");    


    for(int j = 0; j < D_; j++){
      for(int i = 0; i < j; i++){
	W_(i,j) = W_(j,i) = drand48();
	//W_(i,j) = W_(j,i) = 0;
      }
      //W_(j,0) = W_(0,j)= drand48();
      W_(j,j) = 0.0;
    }
    
//     for(int n = 0; n < n_sample; n++){
//       iVector &x_n = xs_[state_select.roll()];
//       //      x_n[0]=0;
//       F_ += outer_prod(x_n, x_n);
//       // { test code 2011/5/31
//       // for(int i=0; i < D_; i++){
//       //  for(int j=0; j < D_; j++){
//       //    F_(i,j) += x_n[i]*x_n[j];
//       //  }
//       //  F_(i,i)=0.0;
//       // }
//       // for(int j=0; j < D_; j++){
// // 	for(int i=0; i < j; i++){
// // 	  F_(i,j) += x_n[i]*x_n[j];
// // 	  F_(j,i)  = F_(i,j);
// // 	}
// // 	F_(i,i)=0.0;
// //       }
//       //}
    //  }
    
    F_ = dZeroMatrix(D_,D_);
    F_(0,1)= F_(1,0) = 0.7; 
    F_(0,2)= F_(2,0) = 0.6;
    F_(0,3)= F_(3,0) = 0.35;
    F_(1,2)= F_(2,1) = 0.7;
    F_(1,3)= F_(3,1) = 0.35;
    F_(2,3)= F_(3,2) = 0.35;
    for(int i=0; i < D_; i++){ F_(i,i) = 0.0; }

    F_ /= n_sample;
    //tF /= n_sample;
    for(int i=0; i < N_; i++){
      std::cout << q_table[i] << "   ";
    }
    std::cout << std::endl;


    //std::cout << "F_ = " << std::endl;
    //print_Matrix<dMatrix>(std::cout, F_);
    //std::cout << "tF = " << std::endl;
    //print_Matrix<dMatrix>(std::cout, tF);

    print_Matrix_column<dMatrix>(ofs4, F_);
    print_Matrix<dMatrix>(std::cout, F_);
    ofs4.close();

    print_vector<std::vector<double> >
      (std::cout, Pr_q_, Pr_q_.size());

    // int test[4]={1,0,1,0};
//     iVector tv(4);
//     dMatrix tm(4,4);
//     tm = dZeroMatrix(4);
//     std::copy(test, test+4, tv.begin());
//     //tm += outer_prod(tv,tv);
//     for(int n=0; n < 3; n++){
//       std::cout << "n = " << n <<"-----------------------" << std::endl;
//       // for(int i=0; i < D_; i++){
// // 	for(int j=0; j < D_; j++){
// // 	  tm(i,j) += tv[i]*tv[j];
// // 	}
// // 	// tm(i,i)=0;
// //       }
//       tm += outer_prod(tv,tv);
//       print_Matrix<dMatrix>(std::cout, tm);
//     }
//     std::cout << "n = " << 3 <<"-----------------------" << std::endl;
//     tm /= 3;
//     print_Matrix<dMatrix>(std::cout, tm);
    
    // {
//       F_(0,1)=F_(1,0)=0.70;
//       F_(0,2)=F_(2,0)=0.60;
//       F_(0,3)=F_(3,0)=0.35;
//       F_(1,2)=F_(2,1)=0.50;
//       F_(1,3)=F_(3,1)=0.20;
//       F_(2,3)=F_(3,2)=0.15;
//       for(int i=0; i < D_; i++){ F_(i,i) = 0.0; }
//     }
    
    


    //assert(false);

    
    // init neural network
    std::fill(x.begin(), x.end(), 0);
    x[0] = 1.;
    // simulation start
    for(int t=0; t < T_; t++){
      // (d)
      x[0] = 1.;
      for(int i=0; i < K_; i++){
	int cell_number = cell_select.roll();

	assert(x[0] == 1);
	update_cell(x, cell_number);
	G_ += outer_prod(x, x);
      }
      for(int i=0; i < D_; i++){ G_(i,i) = 0.0; }
      G_ /= static_cast<double>(K_);

      W_ += 0.01*(F_ - G_);
      // (f) calculate KL-divergence

      //print_Matrix( ofs1, W_);
      print_Matrix_column<dMatrix>(ofs1, W_);
      print_Matrix_column<dMatrix>(ofs4, F_);
      print_Matrix_column<dMatrix>(ofs5, G_);      

      // (h) plot KL-divergence
      ofs2 << t << "   " << KL_divergence() << std::endl;

      {// print probability
	std::vector<double> p_x(N_+1);
	for(int i=0; i < N_; i++){
	  p_x[i]   = eq3<double>(xs_[i]);
	  p_x[N_] += p_x[i];
	}
	print_vector(ofs3, p_x, p_x.size());
      }
      std::cout << "t=" << t << std::endl;

    } // (g)

    ofs1.close();
    ofs2.close();
    ofs3.close();
  }

  void procedure5(double q_table_prior[],
		  double q_table_conditional[],
		  int n_sample = 1000)
  {
    std::ofstream ofs1("procedure5.dat"  );
    std::ofstream ofs2("procedure5KL.dat");
    std::ofstream ofs3("procedure5Pt.dat"); // theorical
    std::ofstream ofs4("procedure5Pe.dat"); // experimental

    procedure4(q_table_prior, n_sample);
    std::copy(q_table_conditional,
	      q_table_conditional + N_,
	      Pr_q_.begin());


    F_ = dZeroMatrix(D_,D_);
    G_ = dZeroMatrix(D_,D_);
    std::cout << "W_=" << W_ << std::endl;
    print_Matrix(std::cout, W_);
    std::cout << "F_=" << F_ << std::endl;
    print_Matrix(std::cout, F_);
    std::cout << "G_=" << G_ << std::endl;
    print_Matrix(std::cout, G_);
    //assert(false);

    std::vector<long long int> count_data   ( N_ );  // F-Q
    std::vector<long long int> count_model_e( N_ ); // G-P
    //    std::vector<double>    frequency(N_);

    iVector x(D_);
    {// init x
      std::fill(x.begin(), x.end(), 0);
      x[0] = 1;
      x[1] = 1;
    }

    iVector x_sr(D_-1);

    std::vector<double> Pr_cell(D_);
    {// init Pr
      Pr_cell[0] = 0.000;
      Pr_cell[1] = 0.000;
      Pr_cell[2] = 0.500;
      Pr_cell[3] = 0.500;
    }

    RollWeightedDie cell_select(  Pr_cell );
    RollWeightedDie state_select(   Pr_q_ );

    std::vector<double> Pr_data(    N_ + 1);
    std::vector<double> Pr_model_t( N_ + 1);
    std::vector<double> Pr_model_e( N_ + 1);
    // for(int i=0; i < n_sample; i++){
//       int n_state = state_select.roll();
//       int n_cell  = cell_select.roll();

//       int state;
//       x[0] = 1;
//       x[1] = 1;
//       update_cell ( x, n_cell );
//       state = btod( x );
//       count_QF[n_state]++;
//       count_PG[  state]++;
//     }
    
//     for(int i=0; i < N_; i++){
//       Pr_data[i]  = count_QF[i]/static_cast<double>(n_sample);
//       Pr_model[i] = count_PG[i]/static_cast<double>(n_sample);

//       ofs3 << i << "   " << Pr_p[i] << std::endl;
//       ofs4 << i << "   " << Pr_q[i] << std::endl;
//     }

    for(int i = 0; i < n_sample; i++){
      int n_state = state_select.roll();
      iVector& x_n = xs_[n_state];
      F_ += outer_prod(x_n, x_n);
      
      count_data[n_state]++;
    }
    F_ /= n_sample;
    //    {debug
//     for(int i=0; i < N_; i++){
//       std::cout << "Pr(x=" << i << ")="
// 		<< count_data[i]/static_cast<double>(n_sample)
// 		<< std::endl;
//     }
//     assert(false);
//  }    debug
    for(int t=0; t < T_; t++){
      // (d)
      for(int i=0; i < K_; i++){
	int n_cell = cell_select.roll();
	assert(x[0] == 1);
	assert(x[1] == 1);
	assert(n_cell != 0);
	assert(n_cell != 1);
	update_cell(x, n_cell);
	G_ += outer_prod(x, x);
      }
      G_ /= static_cast<double>(K_);
      for(int i=0; i < D_; i++){ G_(i,i) = 0.0; }
      
      // (e) update
      W_ += 0.01*(F_ - G_);
      print_Matrix_column<dMatrix>(ofs1, W_);

      count_model_e[btod(x)]++;
      //      print_Matrix<dMatrix>(ofs1, W_);
      // (f) calculate KL-divergence
      // (h) plot KL-divergence
      ofs2 << t << " " << KL_divergence() << std::endl;
  
      {//plot p(x)
	for(int i=0; i < N_; i++){
	  const iVector& x = xs_[i];
	  Pr_model_t[i] = eq3<double>(x);
	  Pr_model_e[i] = count_model_e[i]/
	    static_cast<double>(T_);
	}
	Pr_model_t[N_] = std::accumulate(Pr_model_t.begin(),
					 Pr_model_t.end()-1, 0.0);
	Pr_model_e[N_] = std::accumulate(Pr_model_e.begin(),
					 Pr_model_e.end()-1, 0.0);
	print_vector<std::vector<double> >(ofs3, 
					   Pr_model_t,
					   Pr_model_t.size());
	print_vector<std::vector<double> >(ofs4, 
					   Pr_model_e,
					   Pr_model_e.size());
      } 
    } // (g)
    
    ofs1.close();
    ofs2.close();
    ofs3.close();
    ofs4.close();
  }

  void procedure6(double q_table[], int n_sample = 1000)
  {
    std::vector<long long int> frequency(N_);
    iVector x(D_);
    iVector& x3 = xs_[3];
    iVector& x6 = xs_[6];
    std::vector<double> Pr_cell(D_);
    std::fill(Pr_cell.begin(), Pr_cell.end(), 1./D_        );
    std::copy(q_table        , q_table + N_ , Pr_q_.begin());
    
    std::ofstream ofs1("procedure6.dat"  );
    std::ofstream ofs2("procedure6KL.dat");
    std::ofstream ofs3("procedure6P.dat" );
    
    RollWeightedDie cell_select(  Pr_cell );
    RollWeightedDie state_select( Pr_q_   );
    W_ = dZeroMatrix(D_,D_);
    for(int i = 0; i < D_; i++){
      for(int j = 0; j < D_; j++){
	W_(i,j) += (2.*x3[i]-1.)*(2.*x3[j]-1.);
	W_(i,j) += (2.*x6[i]-1.)*(2.*x6[j]-1.);
      }
      W_(i,i)=0.0;
    }

    for(int i = 0; i < n_sample; i++){
      iVector& xn = xs_[state_select.roll()];
      F_ += outer_prod(xn, xn);
    }
    for(int i=0; i < D_; i++){ F_(i,i) = 0.0; }
    F_ /= n_sample;
    
    std::cout << __FUNCTION__ << __LINE__ << std::endl;    
    std::cout << "W_=" << W_ << std::endl;    
    std::cout << "F_=" << F_ << std::endl;    
    assert(false);

    // *----init neural network----*
    std::fill(x.begin(), x.end(), 0);
    G_ = dZeroMatrix(D_,D_);
    for(int t=0; t < T_; t++){
      // (d)
      for(int i=0; i < K_; i++){
	int j = cell_select.roll();
	update_cell(x, j);
	G_ += outer_prod(x, x);
      }
      for(int i=0; i < D_; i++){ G_(i,i) = 0.0; }
      G_ /= static_cast<double>(K_);
      
      // (e) update
      W_ += 0.01*(F_ - G_);
      // (f) calculate KL-divergence
      print_Matrix<dMatrix>(ofs1, W_);
      // (h) plot KL-divergence
      ofs2 << t << " " << KL_divergence() << std::endl;

      {// print probability
	std::vector<double> p_x(N_+1);
	for(int i=0; i < N_; i++){ p_x[i] = eq3<double>(xs_[i]); }
	p_x[N_] = std::accumulate( p_x.begin(), p_x.end()-1, 0.0 );
	print_vector(ofs3, p_x, p_x.size());
      }
    } // (g)

    std::cout << "T=" << T_ << "K=" << K_ << std::endl;
    assert(false);
    // (i) plot W_(i,j)
    ofs1.close();
    ofs2.close(); 
    ofs3.close();
  }
};

int main(int argc, char** argv)
{
  const int degree	  =              3;
  const int n_pattern     = 0x01 << degree;
  const int repeat	  =          10000;
  const int n_gibbs	  =            100;
  const int matsize	  =       degree+1;
  std::vector<iVector> 
    train_data(n_pattern, iVector(degree));
  
  for(int i = 0; i < n_pattern; i++){
    iVector state(degree  );
    iVector  data(degree+1);
    dtob(i, state);
    data[0] = 1;
    std::copy(state.begin(), state.end(), data.begin()+1);
    train_data[i] = data;
  }
  
  //  assert(false);
  for(int i=0; i < n_pattern; i++){
    std::cout <<            i  << "   "
	      << train_data[i] << std::endl;
  }
  
  //assert(false);
  double q_table[][n_pattern] = {
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 0
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 1
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 2
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 3
    {0.100, 0.100, 0.050, 0.050, 0.100, 0.100, 0.400, 0.100},	// 4
    {0.000, 0.000, 0.000, 0.000, 0.142, 0.142, 0.571, 0.142},	// 5
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 6
    {0    , 0    , 0    , 0    , 0    , 0    , 0    , 0    },	// 7
  };
  
  std::fill(q_table[0], q_table[0]+n_pattern, 1./n_pattern);
  std::fill(q_table[1], q_table[1]+n_pattern, 1./n_pattern);
  std::fill(q_table[2], q_table[2]+n_pattern, 1./n_pattern);
  std::fill(q_table[3], q_table[3]+n_pattern, 1./n_pattern);
  std::fill(q_table[6], q_table[6]+n_pattern, 1./n_pattern);
  std::fill(q_table[7], q_table[7]+n_pattern, 1./n_pattern);
  
  dMatrix L(degree, degree);
  int seed = (argc > 1) ? atoi(argv[1]) : (unsigned)time(NULL);
  srand48(seed);
  BoltzmannMachine bm(matsize, repeat, n_gibbs, n_pattern, train_data);
  iVector x_init(degree);
  
  //  bm.procedure1(1000000);
  //bm.procedure2(    10000);

//   bm.procedure2(   1000);
//   bm.procedure2(  10000);
//   bm.procedure2( 100000);
//   bm.procedure2(1000000);


  //      bm.procedure2(10000000);
  bm.procedure4(q_table[4], 1000);
  //bm.procedure4(q_table[4], 10000);
  // bm.procedure4(q_table[4], 100000);
  //bm.procedure5(q_table[4], q_table[5], 1000);
  //bm.procedure6(q_table[6], 1000);

  return 0;
}
