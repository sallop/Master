#include <iostream>
#include <iomanip>
#include <cstring>
#include <ctime>
#include <sys/time.h>
#include "BoltzmannMachine.hpp"

using namespace std;

void dtob(int src, Pattern& dst)
{
  for (size_t i=0; i < dst.size(); i++)
    dst[i] = (src >> i) & 0x01;
}

template<size_t T>
void dtob(int src, double dst[T])
{
  for (size_t i=0; i < T; i++)
    dst[i] = static_cast<double>((src >> i) & 0x01);
}

double gettimeofday_sec()
{
  struct timeval tv;
  gettimeofday(&tv, NULL);
  return tv.tv_sec + tv.tv_usec * 1e-6;
}

int count_onbit(const Pattern &x)
{
  int cnt=0;
  for (size_t i=0; i < x.size(); i++)
    cnt += x[i];
  return cnt;
} 

int main(int argc, char** argv)
{
  //  int degree = 8;
  int degree = 16;
  int number_of_allpattern = 0x01 << degree;
  const size_t time = 10000;	// 10^4 pattern

  int init_onbit = atoi( argv[1] );
  double value_of_W = atof( argv[2] );
  TimeOfRepeat T(time);
  KstepGibbsSampling K(1);
  DegreeOfVisibleVector D(degree);
  std::vector<Pattern> all_pattern(number_of_allpattern, Pattern(degree));
  double t1,t2;


  Probability input_pattern_distribution( number_of_allpattern,
					  1.0/static_cast<double>( number_of_allpattern ));

  for (int i=0; i < number_of_allpattern; i++){
    dtob(i, all_pattern[i]);
  }

  BoltzmannMachine *pblz0 = new BoltzmannMachine1L( &all_pattern,
						    T,
						    K,
						    D,
						    input_pattern_distribution );

  BoltzmannMachine *pblz1 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 0.0) );

  BoltzmannMachine *pblz2 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 1.0) );
  
  BoltzmannMachine *pblz3 = new BoltzmannMachine1L_threshold( &all_pattern,
							      T,
							      K,
							      D,
							      input_pattern_distribution,
							      Threshold(degree, 2.0) );

  //int x_table[]={ 0, 4, 8, 16, 32 };
  std::vector<int> cnt( time, 0), hist( degree + 1, 0);
  Layer W(degree, degree);
  for (size_t i=0; i < degree; i++){
    for (size_t j=0; j < degree; j++){
      W(i,j) = value_of_W;
    }
    W(i,i) = 0.0;
  }
  
  std::cout << "# degree = "     << degree 
	    << ", time = "       << time
	    << ", init onbit = " << init_onbit
	    << ", value of W = " << value_of_W
	    << std::endl;

  std::cout << "# probability " << std::endl;
  int n;
  for (size_t t=0; t < time; t++){
    Pattern x(degree, 0);
    for (size_t i=0; i < init_onbit; i++)
      { x[i] = 1;}
    x = pblz0->gibbs_sampling(W, x);
    //cnt[t] = count_onbit(x) - init_onbit;
    //cnt[t] = count_onbit(x);
    n = count_onbit(x);
    if(!(n >= 0 && n <= hist.size())){
      std::cout << "n = " << n << std::endl;
      assert(n >= 0 && n < hist.size());
    }
    hist[n]++;
  }

  // std:: cout << std::setw(8)
  // 	     << ( std::accumulate(hist.begin(), hist.end(), 0.0)/
  // 		  static_cast<double>( time ));

  for (size_t i=0; i < hist.size(); i++){
    std:: cout << std::setw(8) << i;
    std:: cout << std::setw(8) 
	       <<(static_cast<double>( hist[i] )/
		  static_cast<double>( time    ))
	       << std::endl;
  }

  return 0;
}
