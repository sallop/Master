#include <cppunit/TestCase.h>
#include <cppunit/TestCaller.h>
#include <cppunit/TestRunner.h>
#include <cppunit/TestAssert.h>
#include <cppunit/Asserter.h>
#include <iostream>
#include <cstdio>
#include <string>
#include "TrainDataFactory.hpp"

void dtob( int* ary, int n, int size )
{ for(int i=0; i < size; i++){ ary[i] = (n >> i) & 0x01; } }

void print_pattern(FILE* fp, const Pattern& pattern)
{
  for(int i=0; i < pattern.size(); i++){
    fprintf(fp, "%04lf\t", pattern(i));
  }
  fprintf(fp, "\n");
}

void make_histgram(int denom, const Pattern& numer, Pattern& hist)
{ for(int i=0; i < numer.size(); i++){ hist[i] = numer[i]/denom; } }

bool operator==( const Pattern& lhs, const Pattern& rhs )
{
  if (lhs.size() != rhs.size()){ return false; }
  for(int i=0; i < lhs.size(); i++){
    if (lhs[i] != rhs[i]){ return false; }
  }
  return true;
}

class TrainDataFactoryTest : public CppUnit::TestCase
{
public:
  TrainDataFactoryTest( std::string name ) : TestCase( name ){}
  void runTest()
  {
    const int size = 10;
    int pattern_tbl[][size] = {
      {0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {1, 0, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 1, 0, 0, 0, 0, 0, 0, 0, 0},
      {1, 1, 0, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 1, 0, 0, 0, 0, 0, 0, 0},
      {1, 0, 1, 0, 0, 0, 0, 0, 0, 0},
      {1, 1, 1, 0, 0, 0, 0, 0, 0, 0},
      {0, 0, 0, 1, 0, 0, 0, 0, 0, 0},
      {1, 0, 0, 1, 0, 0, 0, 0, 0, 0},
      {0, 1, 0, 1, 0, 0, 0, 0, 0, 0},
    };

    ArbitararyTrainData* data_generator = new ArbitararyTrainData(size);
    Pattern p0, p1, p2, p3, p4;
    
    int ary[size]; std::fill( ary, ary + size, 0 );
    for(int i=0; i < size; i++){
      dtob(&ary[0], i, size);
      data_generator->registry( ary, size );
    }

    p0 = data_generator->create( 0 );
    p1 = data_generator->create( 1 );
    p2 = data_generator->create( 2 );
    p3 = data_generator->create( 3 );
    p4 = data_generator->create( 4 );

    std::cout << p0 << std::endl;
    std::cout << p1 << std::endl;
    std::cout << p2 << std::endl;
    std::cout << p3 << std::endl;
    std::cout << p4 << std::endl;

    CPPUNIT_ASSERT(p0 == p0); //    CPPUNIT_ASSERT(p1 == p2);
  }
};

class RandomTrainDataTest : public CppUnit::TestCase
{
public:
  RandomTrainDataTest( std::string name ) : TestCase( name ){}

  void runTest()
  {
    const int size  = 10 ;
    const int count = 10000;
    int pattern[10] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

    RandomTrainData* data_generator = new RandomTrainData( size );
    Pattern p0, p1, p2, p3, p4, p1_1;

    for(int i=0; i < size; i++){
      data_generator->setProb( i, 0.1 );
    }
    
    for(int i=0; i < count; i++){
      data_generator->registry();
    }

    // p0   = data_generator->create( 0 );
    // p1   = data_generator->create( 1 );
    // p2   = data_generator->create( 2 );
    // p3   = data_generator->create( 3 );
    // p4   = data_generator->create( 4 );
    // p1_1 = data_generator->create( 1 );

    std::cout << "p0  = " << p0   << std::endl;
    std::cout << "p1  = " << p1   << std::endl;
    std::cout << "p2  = " << p2   << std::endl;
    std::cout << "p3  = " << p3   << std::endl;
    std::cout << "p4  = " << p4   << std::endl;
    std::cout << std::endl;
    std::cout << "p1  = " << p1   << std::endl;
    std::cout << "p1_1= " << p1_1 << std::endl;

    std::vector<Pattern> ps( count );
    Pattern sum = Pattern0( size );
    for(int i=0; i < count; i++){
      Pattern p = data_generator->create(i);
      sum += p;
    }
    sum /= static_cast<double>(count);
    
    data_generator->printProb();

    std::cout << "sum =" << sum << std::endl;
  }
};

// TrainDataFactoryTest* test
//     = new TrainDataFactoryTest(std::string("Train Data Factory Test") );
//   test->runTest();
//   delete test;

int main(int argc, char* argv[])
{
  RandomTrainDataTest* test2 =
    new RandomTrainDataTest(std::string("Random Train Data Factory Test"));
  test2->runTest();
  delete test2;
  return 0;
}
